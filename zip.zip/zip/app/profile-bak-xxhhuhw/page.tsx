"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import { User, Camera, Building2, Phone, Mail, Calendar, GraduationCap } from "lucide-react"
import { format } from "date-fns"

export default function ProfilePage() {
  const { user, updateUser } = useAuth()
  const [isUploading, setIsUploading] = useState(false)
  const [message, setMessage] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setMessage("Please select a valid image file")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage("File size must be less than 5MB")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    setIsUploading(true)
    try {
      const response = await apiService.updateAvatar(user.nisn, file)
      if (response.success) {
        updateUser(response.data)
        setMessage("Avatar updated successfully!")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error updating avatar:", error)
      setMessage("Error updating avatar")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsUploading(false)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Profile</h1>
          <p className="text-muted-foreground">Manage your personal information and settings</p>
        </div>
      </div>

      {message && (
        <Alert>
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Picture Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Profile Picture
            </CardTitle>
            <CardDescription>Click on the avatar to update your profile picture</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-4">
            <div className="relative">
              <Avatar className="h-32 w-32 cursor-pointer" onClick={handleAvatarClick}>
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="text-2xl">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div
                className="absolute bottom-0 right-0 bg-blue-600 rounded-full p-2 cursor-pointer"
                onClick={handleAvatarClick}
              >
                <Camera className="h-4 w-4 text-white" />
              </div>
            </div>

            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />

            <Button onClick={handleAvatarClick} disabled={isUploading} variant="outline" className="w-full">
              {isUploading ? "Uploading..." : "Change Avatar"}
            </Button>

            <p className="text-xs text-muted-foreground text-center">Supported formats: JPG, PNG, GIF (max 5MB)</p>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              Personal Information
            </CardTitle>
            <CardDescription>Your basic profile information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Full Name</p>
                    <p className="font-medium">{user.name}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">NISN</p>
                    <p className="font-medium">{user.nisn}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Mail className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Email</p>
                    <p className="font-medium">{user.email}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Phone className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <p className="font-medium">{user.phone}</p>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Major</p>
                    <p className="font-medium">{user.jurusan?.name || "Not specified"}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <GraduationCap className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Class</p>
                    <p className="font-medium">{user.kelas?.name || "Not specified"}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <Calendar className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Semester & Year</p>
                    <p className="font-medium">
                      Semester {user.semester} - {user.year}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <User className="h-4 w-4 text-muted-foreground" />
                  <div>
                    <p className="text-sm text-muted-foreground">Account Status</p>
                    <Badge variant={user.activated ? "default" : "secondary"}>
                      {user.activated ? "Activated" : "Pending Activation"}
                    </Badge>
                  </div>
                </div>
              </div>
            </div>

            {user.place_of_birth && user.date_of_birth && (
              <div className="pt-4 border-t">
                <h4 className="font-medium mb-3">Birth Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Place of Birth</p>
                    <p className="font-medium">{user.place_of_birth}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Date of Birth</p>
                    <p className="font-medium">{format(new Date(user.date_of_birth), "MMMM d, yyyy")}</p>
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Company Information */}
      {user.dudi && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Building2 className="h-5 w-5" />
              Internship Company
            </CardTitle>
            <CardDescription>Information about your assigned internship company</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground">Company Name</p>
                  <p className="font-medium text-lg">{user.dudi.name}</p>
                </div>

                <div>
                  <p className="text-sm text-muted-foreground">Address</p>
                  <p className="font-medium">{user.dudi.address}</p>
                </div>
              </div>

              <div className="space-y-4">
                {user.dudi.pic && user.dudi.pic !== "-" && (
                  <div>
                    <p className="text-sm text-muted-foreground">Person in Charge</p>
                    <p className="font-medium">{user.dudi.pic}</p>
                  </div>
                )}

                {user.dudi.contact && user.dudi.contact !== "0" && (
                  <div>
                    <p className="text-sm text-muted-foreground">Contact</p>
                    <p className="font-medium">{user.dudi.contact}</p>
                  </div>
                )}

                <div>
                  <p className="text-sm text-muted-foreground">Registration Date</p>
                  <p className="font-medium">{format(new Date(user.dudi.created_at), "MMMM d, yyyy")}</p>
                </div>
              </div>
            </div>

            {user.dudi.logo && (
              <div className="mt-6 pt-6 border-t">
                <p className="text-sm text-muted-foreground mb-2">Company Logo</p>
                <img
                  src={`http://epkl.smk2-yk.sch.id${user.dudi.logo}`}
                  alt={`${user.dudi.name} logo`}
                  className="h-16 object-contain"
                />
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Account Information */}
      <Card>
        <CardHeader>
          <CardTitle>Account Information</CardTitle>
          <CardDescription>Technical details about your account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Device ID</p>
                <p className="font-mono text-sm">{user.device_id}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Account Created</p>
                <p className="font-medium">{format(new Date(user.created_at), "MMMM d, yyyy HH:mm")}</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Last Updated</p>
                <p className="font-medium">{format(new Date(user.updated_at), "MMMM d, yyyy HH:mm")}</p>
              </div>

              {user.lat && user.long && (
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="font-mono text-sm">
                    {user.lat}, {user.long}
                  </p>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
