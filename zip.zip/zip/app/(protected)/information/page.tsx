"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { apiService } from "@/lib/api"
import type { Info } from "@/types/api"
import { BookOpen, Search, Calendar, ImageIcon } from "lucide-react"
import { format } from "date-fns"
import { InfoDetailDialog } from "@/components/info-detail-dialog"

export default function InformationPage() {
  const [infoList, setInfoList] = useState<Info[]>([])
  const [filteredInfo, setFilteredInfo] = useState<Info[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(true)
  const [selectedInfoId, setSelectedInfoId] = useState<number | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  useEffect(() => {
    fetchInfo()
  }, [])

  useEffect(() => {
    if (searchTerm) {
      const filtered = infoList.filter((info) => info.title.toLowerCase().includes(searchTerm.toLowerCase()))
      setFilteredInfo(filtered)
    } else {
      setFilteredInfo(infoList)
    }
  }, [searchTerm, infoList])

  const fetchInfo = async () => {
    setIsLoading(true)
    try {
      const response = await apiService.getInfo()
      if (response.success) {
        setInfoList(response.data.info)
        setFilteredInfo(response.data.info)
      }
    } catch (error) {
      console.error("Error fetching info:", error)
    }
    setIsLoading(false)
  }

  const handleInfoClick = (infoId: number) => {
    setSelectedInfoId(infoId)
    setIsDetailDialogOpen(true)
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-orange-500 via-red-500 to-pink-600 p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white/20 p-3 rounded-xl">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold">Information Center</h1>
              <p className="text-white/90 text-lg">Stay updated with the latest announcements</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <Calendar className="h-3 w-3 mr-1" />
              {filteredInfo.length} Total Announcements
            </Badge>
          </div>
        </div>
      </div>

      {/* Search */}
      <Card className="border-0 shadow-lg">
        <CardContent className="p-6">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
            <Input
              placeholder="Search announcements..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 text-base border-2 focus:border-orange-300"
            />
          </div>
        </CardContent>
      </Card>

      {/* Information List */}
      <div className="space-y-6">
        {isLoading ? (
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600 mx-auto mb-4"></div>
            <p className="text-gray-600">Loading announcements...</p>
          </div>
        ) : filteredInfo.length === 0 ? (
          <Card className="border-0 shadow-lg">
            <CardContent className="text-center py-12">
              <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">
                {searchTerm ? "No announcements found" : "No announcements available"}
              </h3>
              <p className="text-gray-600">
                {searchTerm ? "Try adjusting your search terms" : "Check back later for updates"}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredInfo.map((info) => (
              <Card
                key={info.id}
                className="border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-gradient-to-br from-white to-gray-50 cursor-pointer"
                onClick={() => handleInfoClick(info.id)}
              >
                <CardHeader className="pb-4">
                  {info.image ? (
                    <div className="relative overflow-hidden rounded-lg mb-4">
                      <img
                        src={`http://epkl.smk2-yk.sch.id${info.image}`}
                        alt={info.title}
                        className="w-full h-48 object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                    </div>
                  ) : (
                    <div className="w-full h-48 bg-gradient-to-br from-orange-100 to-orange-200 rounded-lg flex items-center justify-center mb-4">
                      <ImageIcon className="h-16 w-16 text-orange-600" />
                    </div>
                  )}

                  <CardTitle className="text-lg leading-tight">{info.title}</CardTitle>
                  <CardDescription className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {format(new Date(info.created_at), "MMMM d, yyyy")}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="border-orange-200 text-orange-700">
                      Announcement
                    </Badge>
                    <span className="text-sm text-gray-500">{format(new Date(info.created_at), "HH:mm")}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
      <InfoDetailDialog
        infoId={selectedInfoId}
        isOpen={isDetailDialogOpen}
        onClose={() => setIsDetailDialogOpen(false)}
      />
    </div>
  )
}
