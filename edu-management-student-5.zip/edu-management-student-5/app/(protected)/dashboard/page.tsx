"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import type { Attendance, Info } from "@/types/api"
import { Clock, CheckCircle, XCircle, BookOpen, Building2, AlertCircle, Eye } from "lucide-react"
import { format } from "date-fns"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

// Import the InfoDetailDialog component
import { InfoDetailDialog } from "@/components/info-detail-dialog"
import { CompanySelectionDialog } from "@/components/company-selection-dialog"

export default function DashboardPage() {
  const { user } = useAuth()
  const [todayAttendance, setTodayAttendance] = useState<Attendance | null>(null)
  const [infoList, setInfoList] = useState<Info[]>([])
  const [isCheckingIn, setIsCheckingIn] = useState(false)
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [attendanceMessage, setAttendanceMessage] = useState("")
  const [showCheckInConfirm, setShowCheckInConfirm] = useState(false)
  const [showCheckOutConfirm, setShowCheckOutConfirm] = useState(false)
  const [showCompanySelection, setShowCompanySelection] = useState(false)

  // State for the selected info ID and dialog open state
  const [selectedInfoId, setSelectedInfoId] = useState<number | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  const today = format(new Date(), "MM-dd-yyyy")

  useEffect(() => {
    if (user) {
      fetchTodayAttendance()
      fetchInfo()

      // Show company selection dialog if user doesn't have a company
      if (!user.dudi) {
        setShowCompanySelection(true)
      }
    }
  }, [user])

  const fetchTodayAttendance = async () => {
    if (!user) return

    try {
      const response = await apiService.getAttendanceList(user.nisn, today, today)
      if (response.success && response.data.length > 0) {
        setTodayAttendance(response.data[0])
      }
    } catch (error) {
      console.error("Error fetching attendance:", error)
    }
  }

  const fetchInfo = async () => {
    try {
      const response = await apiService.getInfo()
      if (response.success) {
        setInfoList(response.data.info)
      }
    } catch (error) {
      console.error("Error fetching info:", error)
    }
  }

  const handleCheckIn = async () => {
    if (!user) return

    setIsCheckingIn(true)
    try {
      const response = await apiService.checkIn(user.nisn, today)
      if (response.success) {
        setTodayAttendance(response.data)
        setAttendanceMessage("Successfully checked in!")
        setTimeout(() => setAttendanceMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error checking in:", error)
    }
    setIsCheckingIn(false)
    setShowCheckInConfirm(false)
  }

  const handleCheckOut = async () => {
    if (!user) return

    setIsCheckingOut(true)
    try {
      const response = await apiService.checkOut(user.nisn, today)
      if (response.success) {
        setTodayAttendance(response.data)
        setAttendanceMessage("Successfully checked out!")
        setTimeout(() => setAttendanceMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error checking out:", error)
    }
    setIsCheckingOut(false)
    setShowCheckOutConfirm(false)
  }

  const getAttendanceStatus = () => {
    if (!todayAttendance) {
      return {
        message: "You haven't checked in today",
        variant: "destructive" as const,
        icon: <AlertCircle className="h-4 w-4" />,
        canCheckIn: true,
        canCheckOut: false,
      }
    }

    if (todayAttendance.check_in && !todayAttendance.check_out) {
      return {
        message: "You haven't checked out today",
        variant: "default" as const,
        icon: <Clock className="h-4 w-4" />,
        canCheckIn: false,
        canCheckOut: true,
      }
    }

    if (todayAttendance.check_in && todayAttendance.check_out) {
      return {
        message: "You have completed attendance for today",
        variant: "default" as const,
        icon: <CheckCircle className="h-4 w-4" />,
        canCheckIn: false,
        canCheckOut: false,
      }
    }

    return {
      message: "Unknown attendance status",
      variant: "default" as const,
      icon: <XCircle className="h-4 w-4" />,
      canCheckIn: false,
      canCheckOut: false,
    }
  }

  const attendanceStatus = getAttendanceStatus()

  if (!user) {
    return <div>Loading...</div>
  }

  // Function to handle clicking on an info item
  const handleInfoClick = (infoId: number) => {
    console.log("Clicking info item with ID:", infoId) // Debug log
    setSelectedInfoId(infoId)
    setIsDetailDialogOpen(true)
  }

  return (
    <div className="space-y-6 w-full">
      {/* Header Section */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div className="space-y-1">
          <h1 className="text-2xl lg:text-3xl font-bold text-gray-900">Welcome back, {user.name}!</h1>
          <p className="text-sm lg:text-base text-muted-foreground">
            {user.jurusan?.name} - {user.kelas?.name}
          </p>
        </div>
        <Badge variant="secondary" className="text-sm w-fit">
          Semester {user.semester} - {user.year}
        </Badge>
      </div>

      {/* Success Message */}
      {attendanceMessage && (
        <Alert className="border-green-200 bg-green-50">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">{attendanceMessage}</AlertDescription>
        </Alert>
      )}

      {/* Company Assignment Alert */}
      {!user.dudi && (
        <Alert className="border-orange-200 bg-orange-50">
          <Building2 className="h-4 w-4 text-orange-600" />
          <AlertDescription className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <span className="text-orange-800">You haven't been assigned to an internship company yet.</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowCompanySelection(true)}
              className="border-orange-300 text-orange-700 hover:bg-orange-100 w-fit"
            >
              Select Company
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Main Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-4 lg:gap-6">
        {/* Attendance Card */}
        <Card className="lg:col-span-2 xl:col-span-1 shadow-sm hover:shadow-md transition-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <Clock className="h-5 w-5 text-blue-600" />
              Today's Attendance
            </CardTitle>
            <CardDescription className="text-sm">{format(new Date(), "EEEE, MMMM d, yyyy")}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant={attendanceStatus.variant} className="border-l-4">
              {attendanceStatus.icon}
              <AlertDescription className="text-sm font-medium">{attendanceStatus.message}</AlertDescription>
            </Alert>

            {todayAttendance && (
              <div className="space-y-3 bg-gray-50 p-4 rounded-lg border">
                {todayAttendance.check_in && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 font-medium">Check In:</span>
                    <span className="text-sm font-bold text-green-700 bg-green-100 px-2 py-1 rounded">
                      {format(new Date(Number.parseInt(todayAttendance.check_in) * 1000), "HH:mm:ss")}
                    </span>
                  </div>
                )}
                {todayAttendance.check_out && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600 font-medium">Check Out:</span>
                    <span className="text-sm font-bold text-blue-700 bg-blue-100 px-2 py-1 rounded">
                      {format(new Date(Number.parseInt(todayAttendance.check_out) * 1000), "HH:mm:ss")}
                    </span>
                  </div>
                )}
              </div>
            )}

            <div className="flex flex-col gap-3">
              {attendanceStatus.canCheckIn && (
                <>
                  <Button
                    onClick={() => setShowCheckInConfirm(true)}
                    disabled={isCheckingIn}
                    className="w-full h-14 text-lg font-semibold bg-green-600 hover:bg-green-700 active:scale-95 transition-transform"
                    size="lg"
                  >
                    {isCheckingIn ? "Checking In..." : "Check In"}
                  </Button>

                  <AlertDialog open={showCheckInConfirm} onOpenChange={setShowCheckInConfirm}>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Check In</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to check in? This will mark the start of your work day.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleCheckIn} disabled={isCheckingIn}>
                          {isCheckingIn ? "Checking In..." : "Yes, Check In"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
              {attendanceStatus.canCheckOut && (
                <>
                  <Button
                    onClick={() => setShowCheckOutConfirm(true)}
                    disabled={isCheckingOut}
                    variant="outline"
                    className="w-full h-14 text-lg font-semibold border-blue-300 text-blue-700 hover:bg-blue-50 active:scale-95 transition-transform"
                    size="lg"
                  >
                    {isCheckingOut ? "Checking Out..." : "Check Out"}
                  </Button>

                  <AlertDialog open={showCheckOutConfirm} onOpenChange={setShowCheckOutConfirm}>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Check Out</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to check out? This will mark the end of your work day.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleCheckOut} disabled={isCheckingOut}>
                          {isCheckingOut ? "Checking Out..." : "Yes, Check Out"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Profile Summary */}
        <Card className="shadow-sm hover:shadow-md transition-shadow">
          <CardHeader className="pb-4">
            <CardTitle className="flex items-center gap-2 text-lg">
              <BookOpen className="h-5 w-5 text-indigo-600" />
              Profile Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3 text-sm">
              <div className="flex justify-between items-center py-2 border-b border-gray-100">
                <span className="text-gray-600 font-medium">NISN:</span>
                <span className="font-bold text-gray-900">{user.nisn}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-100">
                <span className="text-gray-600 font-medium">Email:</span>
                <span className="font-bold text-gray-900 truncate ml-2 text-right">{user.email}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-100">
                <span className="text-gray-600 font-medium">Phone:</span>
                <span className="font-bold text-gray-900">{user.phone}</span>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-gray-600 font-medium">Status:</span>
                <Badge variant={user.activated ? "default" : "secondary"} className="text-xs">
                  {user.activated ? "Activated" : "Pending"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Company Info - Responsive layout */}
        {user.dudi ? (
          <Card className="lg:col-span-2 xl:col-span-1 shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Building2 className="h-5 w-5 text-emerald-600" />
                Internship Company
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-gradient-to-r from-emerald-50 to-blue-50 p-4 rounded-lg border border-emerald-100">
                <h3 className="font-bold text-lg text-gray-900 mb-2 leading-tight">{user.dudi.name}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{user.dudi.address}</p>
              </div>

              <div className="space-y-3 text-sm">
                {user.dudi.pic && user.dudi.pic !== "-" && (
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 font-medium">PIC:</span>
                    <span className="font-bold text-gray-900 text-right">{user.dudi.pic}</span>
                  </div>
                )}
                {user.dudi.contact && user.dudi.contact !== "0" && (
                  <div className="flex justify-between items-center">
                    <span className="text-gray-600 font-medium">Contact:</span>
                    <span className="font-bold text-gray-900 text-right">{user.dudi.contact}</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="lg:col-span-2 xl:col-span-1 shadow-sm hover:shadow-md transition-shadow">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Building2 className="h-5 w-5 text-gray-500" />
                Internship Company
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center py-8">
              <div className="text-muted-foreground">
                <Building2 className="h-16 w-16 mx-auto mb-4 opacity-30 text-gray-400" />
                <p className="text-sm mb-4 text-gray-600">No company assigned</p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setShowCompanySelection(true)}
                  className="h-10 px-6 border-gray-300 hover:bg-gray-50"
                >
                  Select Company
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Information Section - Improved responsive layout */}
      {infoList.length > 0 && (
        <Card className="mt-8 shadow-sm">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-orange-600" />
              Latest Information
            </CardTitle>
            <CardDescription>Important announcements and updates - Click to view details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {infoList.slice(0, 6).map((info) => (
                <div
                  key={info.id}
                  className="flex flex-col gap-3 p-4 border border-gray-200 rounded-xl cursor-pointer hover:bg-orange-50 hover:border-orange-300 hover:shadow-md transition-all duration-200 group"
                  onClick={() => handleInfoClick(info.id)}
                >
                  <div className="flex items-start gap-3">
                    {info.image ? (
                      <img
                        src={`http://epkl.smk2-yk.sch.id${info.image}`}
                        alt={info.title}
                        className="w-12 h-12 object-cover rounded-lg flex-shrink-0 border"
                      />
                    ) : (
                      <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center flex-shrink-0">
                        <BookOpen className="h-6 w-6 text-orange-600" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <h4 className="font-semibold text-sm group-hover:text-orange-700 transition-colors leading-tight line-clamp-2">
                        {info.title}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {format(new Date(info.created_at), "MMM d, yyyy")}
                      </p>
                    </div>
                  </div>
                  <div className="flex justify-end">
                    <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                      <Eye className="h-4 w-4 text-orange-600" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* InfoDetailDialog component */}
      <InfoDetailDialog
        infoId={selectedInfoId}
        isOpen={isDetailDialogOpen}
        onClose={() => {
          setIsDetailDialogOpen(false)
          setSelectedInfoId(null)
        }}
      />

      {/* Company Selection Dialog */}
      <CompanySelectionDialog isOpen={showCompanySelection} onClose={() => setShowCompanySelection(false)} />
    </div>
  )
}
