"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import type { Attendance } from "@/types/api"
import { Calendar, Clock, CheckCircle, XCircle, TrendingUp, BarChart3, Timer } from "lucide-react"
import { format, subDays } from "date-fns"

export default function AttendancePage() {
  const { user } = useAuth()
  const [attendanceList, setAttendanceList] = useState<Attendance[]>([])
  const [startDate, setStartDate] = useState(format(subDays(new Date(), 7), "yyyy-MM-dd"))
  const [endDate, setEndDate] = useState(format(new Date(), "yyyy-MM-dd"))
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (user) {
      fetchAttendance()
    }
  }, [user, startDate, endDate])

  const fetchAttendance = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const formattedStartDate = format(new Date(startDate), "MM-dd-yyyy")
      const formattedEndDate = format(new Date(endDate), "MM-dd-yyyy")

      const response = await apiService.getAttendanceList(user.nisn, formattedStartDate, formattedEndDate)
      if (response.success) {
        setAttendanceList(response.data)
      }
    } catch (error) {
      console.error("Error fetching attendance:", error)
    }
    setIsLoading(false)
  }

  const getAttendanceStatus = (attendance: Attendance) => {
    if (attendance.check_in && attendance.check_out) {
      return {
        status: "Complete",
        variant: "default" as const,
        icon: <CheckCircle className="h-4 w-4" />,
        color: "green",
      }
    } else if (attendance.check_in && !attendance.check_out) {
      return {
        status: "Incomplete",
        variant: "secondary" as const,
        icon: <Clock className="h-4 w-4" />,
        color: "yellow",
      }
    } else {
      return { status: "Absent", variant: "destructive" as const, icon: <XCircle className="h-4 w-4" />, color: "red" }
    }
  }

  const formatTime = (timestamp: string | null) => {
    if (!timestamp) return "-"
    return format(new Date(Number.parseInt(timestamp) * 1000), "HH:mm:ss")
  }

  const calculateWorkingHours = (checkIn: string | null, checkOut: string | null) => {
    if (!checkIn || !checkOut) return "-"

    const inTime = new Date(Number.parseInt(checkIn) * 1000)
    const outTime = new Date(Number.parseInt(checkOut) * 1000)
    const diffMs = outTime.getTime() - inTime.getTime()
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60))
    const diffMinutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60))

    return `${diffHours}h ${diffMinutes}m`
  }

  if (!user) {
    return <div>Loading...</div>
  }

  const completeAttendance = attendanceList.filter((a) => a.check_in && a.check_out).length
  const incompleteAttendance = attendanceList.filter((a) => a.check_in && !a.check_out).length
  const absentDays = attendanceList.filter((a) => !a.check_in).length

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-green-500 via-teal-500 to-blue-600 p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white/20 p-3 rounded-xl">
              <Clock className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold">Attendance History</h1>
              <p className="text-white/90 text-lg">Track your attendance records and working hours</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <BarChart3 className="h-3 w-3 mr-1" />
              {attendanceList.length} Total Records
            </Badge>
            <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
              <TrendingUp className="h-3 w-3 mr-1" />
              {completeAttendance} Complete Days
            </Badge>
          </div>
        </div>
      </div>

      {/* Date Filter */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-lg lg:text-xl">
            <div className="bg-blue-500 p-2 rounded-lg">
              <Calendar className="h-5 w-5 text-white" />
            </div>
            Filter by Date Range
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="start-date" className="text-sm font-medium">
                  Start Date
                </Label>
                <Input
                  id="start-date"
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="border-2 h-11"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="end-date" className="text-sm font-medium">
                  End Date
                </Label>
                <Input
                  id="end-date"
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="border-2 h-11"
                />
              </div>
            </div>
            <Button
              onClick={fetchAttendance}
              disabled={isLoading}
              className="w-full sm:w-auto h-11 bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700"
            >
              {isLoading ? "Loading..." : "Filter"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Attendance Summary - Better responsive grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
        <Card className="border-0 shadow-xl bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-green-900">{completeAttendance}</p>
                <p className="text-green-700 font-medium text-sm lg:text-base">Complete Days</p>
              </div>
              <div className="bg-green-500 p-3 lg:p-4 rounded-full">
                <CheckCircle className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-yellow-50 to-yellow-100">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-yellow-900">{incompleteAttendance}</p>
                <p className="text-yellow-700 font-medium text-sm lg:text-base">Incomplete Days</p>
              </div>
              <div className="bg-yellow-500 p-3 lg:p-4 rounded-full">
                <Timer className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-red-50 to-red-100 sm:col-span-2 lg:col-span-1">
          <CardContent className="p-4 lg:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-red-900">{absentDays}</p>
                <p className="text-red-700 font-medium text-sm lg:text-base">Absent Days</p>
              </div>
              <div className="bg-red-500 p-3 lg:p-4 rounded-full">
                <XCircle className="h-6 w-6 lg:h-8 lg:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance List */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-xl">
            <div className="bg-purple-500 p-2 rounded-lg">
              <BarChart3 className="h-5 w-5 text-white" />
            </div>
            Attendance Records
          </CardTitle>
          <CardDescription className="text-base">Detailed view of your attendance history</CardDescription>
        </CardHeader>
        <CardContent>
          {attendanceList.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No attendance records found</h3>
              <p className="text-gray-600">No attendance records found for the selected date range.</p>
            </div>
          ) : (
            <div className="space-y-4">
              {attendanceList.map((attendance) => {
                const status = getAttendanceStatus(attendance)
                return (
                  <div
                    key={attendance.id}
                    className="bg-white border-2 border-gray-100 rounded-xl p-4 lg:p-6 hover:border-gray-200 transition-colors"
                  >
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 lg:gap-6">
                        <div className="text-center bg-gray-50 rounded-xl p-3 lg:p-4 min-w-[80px]">
                          <p className="font-bold text-gray-600 text-xs">{format(new Date(attendance.date), "MMM")}</p>
                          <p className="text-2xl lg:text-3xl font-bold text-gray-900">
                            {format(new Date(attendance.date), "d")}
                          </p>
                          <p className="text-xs text-gray-500 font-medium">
                            {format(new Date(attendance.date), "EEE")}
                          </p>
                        </div>

                        <div className="space-y-3 flex-1">
                          <div className="flex items-center gap-3">
                            <Badge variant={status.variant} className="flex items-center gap-2 px-3 py-1 text-sm">
                              {status.icon}
                              {status.status}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-2 gap-3 text-sm">
                            <div className="bg-green-50 p-3 rounded-lg">
                              <p className="text-green-600 font-medium text-xs">Check In</p>
                              <p className="font-bold text-green-900 text-sm lg:text-base">
                                {formatTime(attendance.check_in)}
                              </p>
                            </div>
                            <div className="bg-blue-50 p-3 rounded-lg">
                              <p className="text-blue-600 font-medium text-xs">Check Out</p>
                              <p className="font-bold text-blue-900 text-sm lg:text-base">
                                {formatTime(attendance.check_out)}
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="text-center lg:text-right bg-purple-50 p-3 lg:p-4 rounded-xl min-w-[120px]">
                        <p className="text-xl lg:text-2xl font-bold text-purple-900">
                          {calculateWorkingHours(attendance.check_in, attendance.check_out)}
                        </p>
                        <p className="text-xs lg:text-sm text-purple-600 font-medium">Working Hours</p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
