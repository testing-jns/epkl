"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import type { Journal } from "@/types/api"
import { BookOpen, Plus, Calendar, Target, Activity, Sparkles, TrendingUp, Edit3, X } from "lucide-react"
import { format } from "date-fns"

export default function JournalPage() {
  const { user } = useAuth()
  const [journals, setJournals] = useState<Journal[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [showForm, setShowForm] = useState(false)
  const [message, setMessage] = useState("")
  const [formData, setFormData] = useState({
    tanggal: format(new Date(), "yyyy-MM-dd"),
    kegiatan: "",
    target: "",
  })

  useEffect(() => {
    if (user) {
      fetchJournals()
    }
  }, [user])

  const fetchJournals = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const response = await apiService.getJournals(user.nisn)
      if (response.success) {
        setJournals(response.data)
      }
    } catch (error) {
      console.error("Error fetching journals:", error)
    }
    setIsLoading(false)
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)
    try {
      const response = await apiService.createJournal(user.nisn, formData)
      if (response.success) {
        setJournals((prev) => [response.data, ...prev])
        setFormData({
          tanggal: format(new Date(), "yyyy-MM-dd"),
          kegiatan: "",
          target: "",
        })
        setShowForm(false)
        setMessage("Journal entry created successfully!")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error creating journal:", error)
      setMessage("Error creating journal entry")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsSubmitting(false)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  if (!user) {
    return <div>Loading...</div>
  }

  const thisMonthEntries = journals.filter(
    (j) => format(new Date(j.tanggal), "yyyy-MM") === format(new Date(), "yyyy-MM"),
  ).length
  const todayEntries = journals.filter(
    (j) => format(new Date(j.tanggal), "yyyy-MM-dd") === format(new Date(), "yyyy-MM-dd"),
  ).length

  return (
    <div className="space-y-4 sm:space-y-6 lg:space-y-8 px-2 sm:px-4 lg:px-6">
      {/* Header - Responsive */}
      <div className="relative overflow-hidden rounded-2xl sm:rounded-3xl bg-gradient-to-br from-purple-600 via-pink-500 to-red-500 p-4 sm:p-6 lg:p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-32 h-32 sm:w-48 sm:h-48 lg:w-64 lg:h-64 bg-white/10 rounded-full -translate-y-16 sm:-translate-y-24 lg:-translate-y-32 translate-x-16 sm:translate-x-24 lg:translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-24 h-24 sm:w-36 sm:h-36 lg:w-48 lg:h-48 bg-white/5 rounded-full translate-y-12 sm:translate-y-18 lg:translate-y-24 -translate-x-12 sm:-translate-x-18 lg:-translate-x-24"></div>

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-6">
            <div className="bg-white/20 p-2 sm:p-3 lg:p-4 rounded-lg sm:rounded-xl self-start">
              <BookOpen className="h-6 w-6 sm:h-8 sm:w-8 lg:h-10 lg:w-10 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold leading-tight">Activity Journal</h1>
              <p className="text-white/90 text-sm sm:text-base lg:text-lg mt-1">
                Record your daily activities and achievements
              </p>
              <div className="flex flex-wrap items-center gap-2 sm:gap-4 mt-2 sm:mt-3">
                <div className="flex items-center gap-1 sm:gap-2">
                  <Sparkles className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span className="text-white/90 text-xs sm:text-sm">{journals.length} Total Entries</span>
                </div>
                <div className="flex items-center gap-1 sm:gap-2">
                  <TrendingUp className="h-3 w-3 sm:h-4 sm:w-4" />
                  <span className="text-white/90 text-xs sm:text-sm">{thisMonthEntries} This Month</span>
                </div>
              </div>
            </div>
          </div>

          <Button
            onClick={() => setShowForm(!showForm)}
            className="bg-white/20 text-white border-white/30 hover:bg-white/30 h-10 sm:h-12 px-4 sm:px-6 w-full sm:w-auto"
            size="lg"
          >
            <Plus className="h-4 w-4 sm:h-5 sm:w-5 mr-2" />
            <span className="hidden sm:inline">Add Entry</span>
            <span className="sm:hidden">Add</span>
          </Button>
        </div>
      </div>

      {message && (
        <Alert className="border-green-200 bg-green-50 mx-2 sm:mx-0">
          <Sparkles className="h-4 w-4 text-green-600" />
          <AlertDescription className="text-green-800">{message}</AlertDescription>
        </Alert>
      )}

      {/* Add Journal Form - Mobile Optimized */}
      {showForm && (
        <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-purple-50 mx-2 sm:mx-0">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3 text-lg sm:text-xl">
                <div className="bg-purple-500 p-2 rounded-lg">
                  <Edit3 className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
                </div>
                New Journal Entry
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={() => setShowForm(false)} className="sm:hidden">
                <X className="h-4 w-4" />
              </Button>
            </div>
            <CardDescription className="text-sm sm:text-base">
              Record your activities and targets for the day
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
              <div className="space-y-2">
                <Label htmlFor="tanggal" className="text-sm sm:text-base font-medium">
                  Date
                </Label>
                <Input
                  id="tanggal"
                  type="date"
                  value={formData.tanggal}
                  onChange={(e) => handleInputChange("tanggal", e.target.value)}
                  className="border-2 h-10 sm:h-12 text-sm sm:text-base"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="kegiatan" className="text-sm sm:text-base font-medium">
                  Activity
                </Label>
                <Textarea
                  id="kegiatan"
                  value={formData.kegiatan}
                  onChange={(e) => handleInputChange("kegiatan", e.target.value)}
                  placeholder="Describe your activities for the day..."
                  rows={3}
                  className="border-2 resize-none text-sm sm:text-base min-h-[80px] sm:min-h-[100px]"
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="target" className="text-sm sm:text-base font-medium">
                  Target/Goal
                </Label>
                <Textarea
                  id="target"
                  value={formData.target}
                  onChange={(e) => handleInputChange("target", e.target.value)}
                  placeholder="What did you aim to achieve?"
                  rows={2}
                  className="border-2 resize-none text-sm sm:text-base min-h-[60px] sm:min-h-[80px]"
                  required
                />
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  type="submit"
                  disabled={isSubmitting}
                  className="flex-1 h-10 sm:h-12 bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-sm sm:text-base"
                >
                  {isSubmitting ? "Saving..." : "Save Entry"}
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowForm(false)}
                  className="h-10 sm:h-12 border-2 hidden sm:flex"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      )}

      {/* Journal Statistics - Responsive Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 lg:gap-6 px-2 sm:px-0">
        <Card className="border-0 shadow-xl bg-gradient-to-br from-blue-50 to-blue-100">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl sm:text-3xl font-bold text-blue-900">{journals.length}</p>
                <p className="text-blue-700 font-medium text-sm sm:text-base">Total Entries</p>
              </div>
              <div className="bg-blue-500 p-3 sm:p-4 rounded-full">
                <BookOpen className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-green-50 to-green-100">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl sm:text-3xl font-bold text-green-900">{thisMonthEntries}</p>
                <p className="text-green-700 font-medium text-sm sm:text-base">This Month</p>
              </div>
              <div className="bg-green-500 p-3 sm:p-4 rounded-full">
                <Calendar className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-0 shadow-xl bg-gradient-to-br from-purple-50 to-purple-100 sm:col-span-2 lg:col-span-1">
          <CardContent className="p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-2xl sm:text-3xl font-bold text-purple-900">{todayEntries}</p>
                <p className="text-purple-700 font-medium text-sm sm:text-base">Today</p>
              </div>
              <div className="bg-purple-500 p-3 sm:p-4 rounded-full">
                <Activity className="h-6 w-6 sm:h-8 sm:w-8 text-white" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Journal Entries - Mobile Optimized */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50 mx-2 sm:mx-0">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-3 text-lg sm:text-xl">
            <div className="bg-orange-500 p-2 rounded-lg">
              <BookOpen className="h-4 w-4 sm:h-5 sm:w-5 text-white" />
            </div>
            Journal Entries
          </CardTitle>
          <CardDescription className="text-sm sm:text-base">Your recorded activities and targets</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="text-center py-8 sm:py-12">
              <div className="animate-spin rounded-full h-8 w-8 sm:h-12 sm:w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
              <p className="text-gray-600 text-sm sm:text-base">Loading journal entries...</p>
            </div>
          ) : journals.length === 0 ? (
            <div className="text-center py-8 sm:py-12">
              <BookOpen className="h-12 w-12 sm:h-16 sm:w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg sm:text-xl font-semibold text-gray-900 mb-2">No journal entries yet</h3>
              <p className="text-gray-600 mb-4 text-sm sm:text-base">Start recording your daily activities!</p>
              <Button
                onClick={() => setShowForm(true)}
                className="bg-gradient-to-r from-purple-500 to-purple-600 text-sm sm:text-base h-10 sm:h-12"
              >
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Entry
              </Button>
            </div>
          ) : (
            <div className="space-y-4 sm:space-y-6">
              {journals.map((journal) => (
                <div
                  key={journal.id}
                  className="bg-white border-2 border-gray-100 rounded-xl p-4 sm:p-6 hover:border-purple-200 transition-all duration-300 hover:shadow-lg"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between mb-4 gap-3">
                    <div className="flex items-start gap-3 sm:gap-4 min-w-0 flex-1">
                      <div className="bg-purple-100 p-2 sm:p-3 rounded-xl flex-shrink-0">
                        <Calendar className="h-4 w-4 sm:h-6 sm:w-6 text-purple-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <h3 className="font-bold text-base sm:text-lg text-gray-900 leading-tight">
                          {format(new Date(journal.tanggal), "EEEE, MMMM d, yyyy")}
                        </h3>
                        <p className="text-xs sm:text-sm text-gray-500 mt-1">
                          Created at {format(new Date(journal.created_at), "HH:mm")}
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3 sm:space-y-4">
                    <div className="bg-blue-50 p-3 sm:p-4 rounded-xl">
                      <div className="flex items-center gap-2 sm:gap-3 mb-2">
                        <Activity className="h-4 w-4 sm:h-5 sm:w-5 text-blue-600" />
                        <span className="font-semibold text-blue-900 text-sm sm:text-base">Activities</span>
                      </div>
                      <p className="text-gray-700 leading-relaxed text-sm sm:text-base break-words">
                        {journal.kegiatan}
                      </p>
                    </div>

                    <div className="bg-green-50 p-3 sm:p-4 rounded-xl">
                      <div className="flex items-center gap-2 sm:gap-3 mb-2">
                        <Target className="h-4 w-4 sm:h-5 sm:w-5 text-green-600" />
                        <span className="font-semibold text-green-900 text-sm sm:text-base">Target/Goal</span>
                      </div>
                      <p className="text-gray-700 leading-relaxed text-sm sm:text-base break-words">{journal.target}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
