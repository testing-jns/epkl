"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import {
  User,
  Camera,
  Building2,
  Phone,
  Mail,
  Calendar,
  GraduationCap,
  Edit,
  MapPin,
  Users,
  Save,
  X,
} from "lucide-react"
import { format } from "date-fns"

export default function ProfilePage() {
  const { user, updateUser, refreshUserProfile } = useAuth()
  const [isUploading, setIsUploading] = useState(false)
  const [message, setMessage] = useState("")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editForm, setEditForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
  })
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (user) {
      refreshUserProfile()
    }
  }, [])

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setMessage("Please select a valid image file")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage("File size must be less than 5MB")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    setIsUploading(true)
    try {
      const response = await apiService.updateAvatar(user.nisn, file)
      if (response.success) {
        updateUser(response.data)
        setMessage("Avatar updated successfully!")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error updating avatar:", error)
      setMessage("Error updating avatar")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsUploading(false)
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)
    try {
      const response = await apiService.updateProfile(user.nisn, {
        name: editForm.name,
        phone: editForm.phone,
      })

      if (response.success) {
        updateUser(response.data)
        setMessage("Profile updated successfully!")
        setIsEditDialogOpen(false)
      } else {
        setMessage("Error updating profile")
      }
    } catch (error) {
      console.error("Error updating profile:", error)
      setMessage("Error updating profile")
    }
    setIsSubmitting(false)
    setTimeout(() => setMessage(""), 3000)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="space-y-4 sm:space-y-6 lg:space-y-8 p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
        {/* Header - Mobile Optimized */}
        <div className="relative overflow-hidden rounded-xl sm:rounded-2xl lg:rounded-3xl bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 p-4 sm:p-6 lg:p-8 text-white">
          <div className="absolute inset-0 bg-black/20"></div>
          <div className="absolute top-0 right-0 w-24 h-24 sm:w-32 sm:h-32 lg:w-64 lg:h-64 bg-white/10 rounded-full -translate-y-12 sm:-translate-y-16 lg:-translate-y-32 translate-x-12 sm:translate-x-16 lg:translate-x-32"></div>
          <div className="absolute bottom-0 left-0 w-20 h-20 sm:w-24 sm:h-24 lg:w-48 lg:h-48 bg-white/5 rounded-full translate-y-10 sm:translate-y-12 lg:translate-y-24 -translate-x-10 sm:-translate-x-12 lg:-translate-x-24"></div>

          <div className="relative z-10 space-y-4">
            <div className="flex flex-col space-y-4">
              <div className="flex items-start space-x-4">
                <div className="relative flex-shrink-0">
                  <Avatar className="h-16 w-16 sm:h-20 sm:w-20 lg:h-24 lg:w-24 border-2 sm:border-4 border-white/30">
                    <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                    <AvatarFallback className="bg-white/20 text-white text-lg sm:text-xl lg:text-2xl">
                      {user.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")
                        .toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                </div>
                <div className="min-w-0 flex-1">
                  <h1 className="text-xl sm:text-2xl lg:text-4xl font-bold leading-tight break-words">{user.name}</h1>
                  <p className="text-white/90 text-sm sm:text-base lg:text-lg mt-1 break-all">{user.email}</p>
                  <div className="flex flex-wrap items-center gap-2 mt-2">
                    <Badge variant="secondary" className="bg-white/20 text-white border-white/30 text-xs">
                      <GraduationCap className="h-3 w-3 mr-1" />
                      {user.nisn}
                    </Badge>
                    <Badge
                      variant="secondary"
                      className={`text-xs ${user.activated ? "bg-green-500/20 text-green-100 border-green-300/30" : "bg-yellow-500/20 text-yellow-100 border-yellow-300/30"}`}
                    >
                      {user.activated ? "Activated" : "Pending"}
                    </Badge>
                  </div>
                </div>
              </div>

              <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                <DialogTrigger asChild>
                  <Button
                    variant="secondary"
                    className="bg-white/20 text-white border-white/30 hover:bg-white/30 h-10 w-full sm:w-auto text-sm"
                  >
                    <Edit className="h-4 w-4 mr-2" />
                    Edit Profile
                  </Button>
                </DialogTrigger>
                <DialogContent className="w-[95vw] max-w-md mx-auto">
                  <DialogHeader>
                    <DialogTitle className="text-lg">Edit Profile</DialogTitle>
                    <DialogDescription className="text-sm">Update your personal information</DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleEditSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="edit-name" className="text-sm">
                        Full Name
                      </Label>
                      <Input
                        id="edit-name"
                        value={editForm.name}
                        onChange={(e) => setEditForm((prev) => ({ ...prev, name: e.target.value }))}
                        className="h-12 text-base"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="edit-phone" className="text-sm">
                        Phone
                      </Label>
                      <Input
                        id="edit-phone"
                        value={editForm.phone}
                        onChange={(e) => setEditForm((prev) => ({ ...prev, phone: e.target.value }))}
                        className="h-12 text-base"
                        required
                      />
                    </div>
                    <div className="flex gap-2">
                      <Button type="submit" className="flex-1 h-12" disabled={isSubmitting}>
                        <Save className="h-4 w-4 mr-2" />
                        {isSubmitting ? "Saving..." : "Save"}
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsEditDialogOpen(false)}
                        className="h-12 px-4"
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </div>
        </div>

        {message && (
          <Alert>
            <AlertDescription className="text-sm">{message}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4 sm:space-y-6 lg:space-y-8">
          {/* Profile Picture Card - Mobile First */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-purple-50">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-lg">
                <div className="bg-purple-500 p-2 rounded-lg">
                  <User className="h-4 w-4 text-white" />
                </div>
                Profile Picture
              </CardTitle>
              <CardDescription className="text-sm">Tap the avatar to update your profile picture</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col items-center space-y-4">
              <div className="relative group">
                <Avatar
                  className="h-32 w-32 sm:h-36 sm:w-36 lg:h-40 lg:w-40 cursor-pointer transition-transform active:scale-95 sm:group-hover:scale-105"
                  onClick={handleAvatarClick}
                >
                  <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                  <AvatarFallback className="text-2xl bg-gradient-to-br from-purple-100 to-purple-200 text-purple-700">
                    {user.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")
                      .toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div
                  className="absolute bottom-2 right-2 bg-purple-600 rounded-full p-2 cursor-pointer shadow-lg active:bg-purple-700 transition-colors"
                  onClick={handleAvatarClick}
                >
                  <Camera className="h-4 w-4 text-white" />
                </div>
              </div>

              <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />

              <Button
                onClick={handleAvatarClick}
                disabled={isUploading}
                variant="outline"
                className="w-full h-12 border-2 border-purple-200 hover:border-purple-300 text-sm"
              >
                {isUploading ? "Uploading..." : "Change Avatar"}
              </Button>

              <p className="text-xs text-gray-500 text-center px-4">Supported: JPG, PNG, GIF (max 5MB)</p>
            </CardContent>
          </Card>

          {/* Personal Information - Mobile Optimized Grid */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-blue-50">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-lg">
                <div className="bg-blue-500 p-2 rounded-lg">
                  <User className="h-4 w-4 text-white" />
                </div>
                Personal Information
              </CardTitle>
              <CardDescription className="text-sm">Your basic profile information</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <User className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Full Name</span>
                  </div>
                  <p className="text-base font-medium text-gray-900 break-words">{user.name}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">NISN</span>
                  </div>
                  <p className="text-base font-medium text-gray-900">{user.nisn}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Mail className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Email</span>
                  </div>
                  <p className="text-base font-medium text-gray-900 break-all">{user.email}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Phone className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Phone</span>
                  </div>
                  <p className="text-base font-medium text-gray-900">{user.phone}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Major</span>
                  </div>
                  <p className="text-base font-medium text-gray-900">{user.jurusan?.name || "Not specified"}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Class</span>
                  </div>
                  <p className="text-base font-medium text-gray-900">{user.kelas?.name || "Not specified"}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Calendar className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Semester & Year</span>
                  </div>
                  <p className="text-base font-medium text-gray-900">
                    Semester {user.semester} - {user.year}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <User className="h-4 w-4 text-blue-600" />
                    <span className="font-semibold text-blue-900 text-sm">Account Status</span>
                  </div>
                  <Badge variant={user.activated ? "default" : "secondary"} className="text-sm px-3 py-1">
                    {user.activated ? "Activated" : "Pending Activation"}
                  </Badge>
                </div>
              </div>

              {/* Birth Information - Mobile Optimized */}
              {(user.place_of_birth || user.date_of_birth) && (
                <div className="pt-4 border-t border-blue-100">
                  <h4 className="font-bold text-lg text-blue-900 mb-4">Birth Information</h4>
                  <div className="space-y-4">
                    {user.place_of_birth && (
                      <div className="bg-white p-4 rounded-xl border border-blue-100">
                        <p className="font-semibold text-blue-900 mb-1 text-sm">Place of Birth</p>
                        <p className="text-base font-medium text-gray-900">{user.place_of_birth}</p>
                      </div>
                    )}
                    {user.date_of_birth && (
                      <div className="bg-white p-4 rounded-xl border border-blue-100">
                        <p className="font-semibold text-blue-900 mb-1 text-sm">Date of Birth</p>
                        <p className="text-base font-medium text-gray-900">
                          {format(new Date(user.date_of_birth), "MMMM d, yyyy")}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Company Information - Mobile Optimized */}
          {user.dudi && (
            <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-green-50">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-3 text-lg">
                  <div className="bg-green-500 p-2 rounded-lg">
                    <Building2 className="h-4 w-4 text-white" />
                  </div>
                  Internship Company
                </CardTitle>
                <CardDescription className="text-sm">
                  Information about your assigned internship company
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="bg-white p-4 rounded-xl border border-green-100">
                  <h3 className="font-bold text-xl text-green-900 mb-4 break-words">{user.dudi.name}</h3>

                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <MapPin className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-green-900 text-sm">Address</p>
                        <p className="text-gray-700 text-sm break-words">{user.dudi.address}</p>
                      </div>
                    </div>

                    {user.dudi.pic && user.dudi.pic !== "-" && (
                      <div className="flex items-start gap-3">
                        <Users className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-green-900 text-sm">Person in Charge</p>
                          <p className="text-gray-700 text-sm break-words">{user.dudi.pic}</p>
                        </div>
                      </div>
                    )}

                    {user.dudi.contact && user.dudi.contact !== "0" && (
                      <div className="flex items-start gap-3">
                        <Phone className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                        <div className="min-w-0 flex-1">
                          <p className="font-semibold text-green-900 text-sm">Contact</p>
                          <p className="text-gray-700 text-sm">{user.dudi.contact}</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-start gap-3">
                      <Calendar className="h-4 w-4 text-green-600 mt-1 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-green-900 text-sm">Registration Date</p>
                        <p className="text-gray-700 text-sm">
                          {format(new Date(user.dudi.created_at), "MMMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                  </div>

                  {user.dudi.logo && (
                    <div className="mt-4 pt-4 border-t border-green-200">
                      <p className="font-semibold text-green-900 mb-3 text-sm">Company Logo</p>
                      <img
                        src={`http://epkl.smk2-yk.sch.id${user.dudi.logo}`}
                        alt={`${user.dudi.name} logo`}
                        className="h-16 object-contain border border-green-200 rounded-lg p-2"
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Guidance Information - Mobile Optimized */}
          {user.bimbingan && (
            <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-purple-50">
              <CardHeader className="pb-4">
                <CardTitle className="flex items-center gap-3 text-lg">
                  <div className="bg-purple-500 p-2 rounded-lg">
                    <Users className="h-4 w-4 text-white" />
                  </div>
                  Guidance Counselor
                </CardTitle>
                <CardDescription className="text-sm">Your assigned guidance counselor information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-white p-4 rounded-xl border border-purple-100">
                  <h3 className="font-bold text-xl text-purple-900 mb-2 break-words">{user.bimbingan.name}</h3>
                  <p className="text-purple-600 font-medium mb-4 text-sm">{user.bimbingan.position}</p>

                  <div className="space-y-4">
                    <div className="flex items-center gap-3">
                      <Mail className="h-4 w-4 text-purple-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-purple-900 text-sm">Email</p>
                        <p className="text-gray-700 text-sm break-all">{user.bimbingan.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <Phone className="h-4 w-4 text-purple-600 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <p className="font-semibold text-purple-900 text-sm">Phone</p>
                        <p className="text-gray-700 text-sm">{user.bimbingan.phone}</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Account Information - Mobile Optimized */}
          <Card className="border-0 shadow-lg bg-gradient-to-br from-white to-gray-50">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-3 text-lg">
                <div className="bg-gray-500 p-2 rounded-lg">
                  <User className="h-4 w-4 text-white" />
                </div>
                Account Information
              </CardTitle>
              <CardDescription className="text-sm">Technical details about your account</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-white p-4 rounded-xl border border-gray-100">
                  <p className="font-semibold text-gray-900 mb-1 text-sm">Device ID</p>
                  <p className="font-mono text-xs text-gray-700 break-all">{user.device_id}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-gray-100">
                  <p className="font-semibold text-gray-900 mb-1 text-sm">Account Created</p>
                  <p className="text-gray-700 text-sm">{format(new Date(user.created_at), "MMM d, yyyy")}</p>
                  <p className="text-xs text-gray-500">{format(new Date(user.created_at), "HH:mm")}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border border-gray-100">
                  <p className="font-semibold text-gray-900 mb-1 text-sm">Last Updated</p>
                  <p className="text-gray-700 text-sm">{format(new Date(user.updated_at), "MMM d, yyyy")}</p>
                  <p className="text-xs text-gray-500">{format(new Date(user.updated_at), "HH:mm")}</p>
                </div>

                {user.lat && user.long && (
                  <div className="bg-white p-4 rounded-xl border border-gray-100">
                    <p className="font-semibold text-gray-900 mb-1 text-sm">Location</p>
                    <p className="font-mono text-xs text-gray-700 break-all">
                      {user.lat}, {user.long}
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
