export function generateDeviceId(): string {
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
  let result = ""
  for (let i = 0; i < 16; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length))
  }
  return result
}

export function getOrCreateDeviceId(): string {
  if (typeof window === "undefined") return generateDeviceId()

  let deviceId = localStorage.getItem("device_id")
  if (!deviceId) {
    deviceId = generateDeviceId()
    localStorage.setItem("device_id", deviceId)
  }
  return deviceId
}
