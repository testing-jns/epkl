"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { apiService } from "@/lib/api"
import { Calendar, User, ImageIcon, AlertCircle, X } from "lucide-react"
import { format } from "date-fns"

interface InfoDetailDialogProps {
  infoId: number | null
  isOpen: boolean
  onClose: () => void
}

interface InfoDetail {
  id: number
  title: string
  info: string
  image: string | null
  other: string | null
  created_by: string
  created_at: string
  updated_at: string
}

export function InfoDetailDialog({ infoId, isOpen, onClose }: InfoDetailDialogProps) {
  const [infoDetail, setInfoDetail] = useState<InfoDetail | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [imageError, setImageError] = useState(false)

  // Fetch data when dialog opens and infoId is available
  useEffect(() => {
    if (isOpen && infoId) {
      fetchInfoDetail(infoId)
    }
  }, [isOpen, infoId])

  // Reset state when dialog closes
  useEffect(() => {
    if (!isOpen) {
      setInfoDetail(null)
      setError(null)
      setIsLoading(false)
      setImageError(false)
    }
  }, [isOpen])

  const fetchInfoDetail = async (id: number) => {
    setIsLoading(true)
    setError(null)
    setImageError(false)
    try {
      console.log("Fetching info detail for ID:", id) // Debug log
      const response = await apiService.getInfoDetail(id)
      console.log("Info detail response:", response) // Debug log

      if (response.success) {
        setInfoDetail(response.data)
      } else {
        setError(response.message || "Failed to load information details")
      }
    } catch (error) {
      console.error("Error fetching info detail:", error)
      setError("Failed to load information details")
    }
    setIsLoading(false)
  }

  // Simplified handleOpenChange - only handle closing
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }

  const handleImageError = () => {
    setImageError(true)
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl lg:max-w-4xl max-h-[90vh] sm:max-h-[85vh] overflow-hidden flex flex-col p-0">
        {/* Header - Fixed */}
        <DialogHeader className="p-4 sm:p-6 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-start justify-between gap-4">
            <div className="min-w-0 flex-1">
              <DialogTitle className="text-lg sm:text-xl lg:text-2xl font-bold leading-tight pr-2">
                {isLoading ? "Loading..." : error ? "Error" : infoDetail?.title || "Information Details"}
              </DialogTitle>
              <DialogDescription className="text-muted-foreground text-sm sm:text-base mt-1">
                {isLoading
                  ? "Please wait while we load the information details..."
                  : error
                    ? "There was an error loading the information details."
                    : "Detailed information and announcements"}
              </DialogDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={onClose} className="flex-shrink-0 h-8 w-8 p-0 sm:hidden">
              <X className="h-4 w-4" />
            </Button>
          </div>
        </DialogHeader>

        {/* Content - Scrollable */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {isLoading ? (
            <div className="flex items-center justify-center py-8 sm:py-12">
              <div className="animate-spin rounded-full h-6 w-6 sm:h-8 sm:w-8 border-b-2 border-orange-600"></div>
              <span className="ml-3 text-sm sm:text-base">Loading information details...</span>
            </div>
          ) : error ? (
            <div className="text-center py-8 sm:py-12">
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="text-sm sm:text-base">{error}</AlertDescription>
              </Alert>
            </div>
          ) : infoDetail ? (
            <div className="space-y-4 sm:space-y-6">
              {/* Meta Information */}
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-xs sm:text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Calendar className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                  <span className="break-words">
                    {format(new Date(infoDetail.created_at), "MMMM d, yyyy 'at' HH:mm")}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <User className="h-3 w-3 sm:h-4 sm:w-4 flex-shrink-0" />
                  <span className="break-words">By: {infoDetail.created_by}</span>
                </div>
                <Badge variant="outline" className="self-start sm:self-auto">
                  Announcement
                </Badge>
              </div>

              {/* Image */}
              {infoDetail.image && !imageError && (
                <div className="relative overflow-hidden rounded-lg sm:rounded-xl">
                  <img
                    src={`http://epkl.smk2-yk.sch.id${infoDetail.image}`}
                    alt={infoDetail.title}
                    className="w-full max-h-48 sm:max-h-64 lg:max-h-96 object-cover"
                    onError={handleImageError}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
                </div>
              )}

              {/* Image Error Fallback */}
              {infoDetail.image && imageError && (
                <div className="w-full h-32 sm:h-48 bg-gradient-to-br from-orange-100 to-orange-200 rounded-lg sm:rounded-xl flex items-center justify-center">
                  <div className="text-center">
                    <ImageIcon className="h-8 w-8 sm:h-12 sm:w-12 text-orange-600 mx-auto mb-2" />
                    <p className="text-orange-700 text-xs sm:text-sm">Image could not be loaded</p>
                  </div>
                </div>
              )}

              {/* Main Content */}
              <div className="space-y-4 sm:space-y-6">
                <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 sm:p-6 rounded-lg sm:rounded-xl border border-orange-200">
                  <h3 className="text-base sm:text-lg font-semibold text-orange-900 mb-3 flex items-center gap-2">
                    <ImageIcon className="h-4 w-4 sm:h-5 sm:w-5 flex-shrink-0" />
                    Information Details
                  </h3>
                  <div className="text-gray-800 leading-relaxed whitespace-pre-wrap text-sm sm:text-base break-words">
                    {infoDetail.info}
                  </div>
                </div>

                {/* Additional Information */}
                {infoDetail.other && (
                  <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 sm:p-6 rounded-lg sm:rounded-xl border border-blue-200">
                    <h3 className="text-base sm:text-lg font-semibold text-blue-900 mb-3">Additional Information</h3>
                    <div className="text-gray-800 leading-relaxed whitespace-pre-wrap text-sm sm:text-base break-words">
                      {infoDetail.other}
                    </div>
                  </div>
                )}

                {/* Footer Information */}
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between pt-4 border-t border-gray-200 gap-2 text-xs sm:text-sm text-muted-foreground">
                  <span>Created: {format(new Date(infoDetail.created_at), "PPP")}</span>
                  <span>Updated: {format(new Date(infoDetail.updated_at), "PPP")}</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 sm:py-12">
              <p className="text-muted-foreground text-sm sm:text-base">No information details available.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}
