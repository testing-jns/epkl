"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { usePathname, useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useAuth } from "@/contexts/auth-context"
import { LayoutDashboard, Clock, BookOpen, User, LogOut, Menu, X, GraduationCap, Info } from "lucide-react"
import { cn } from "@/lib/utils"

const navigation = [
  { name: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
  { name: "Attendance", href: "/attendance", icon: Clock },
  { name: "Journal", href: "/journal", icon: BookOpen },
  { name: "Information", href: "/information", icon: Info },
  { name: "Profile", href: "/profile", icon: User },
]

export function Sidebar() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const pathname = usePathname()
  const router = useRouter()
  const { user, logout } = useAuth()

  // Close mobile menu when route changes
  useEffect(() => {
    setIsMobileMenuOpen(false)
  }, [pathname])

  // Close mobile menu on window resize to desktop
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false)
      }
    }

    window.addEventListener("resize", handleResize)
    return () => window.removeEventListener("resize", handleResize)
  }, [])

  const handleLogout = () => {
    logout()
    router.push("/login")
  }

  if (!user) return null

  return (
    <>
      {/* Mobile menu button - Fixed positioning for better accessibility */}
      <div className="lg:hidden fixed top-4 left-4 z-[60] bg-white rounded-lg shadow-lg">
        <Button
          variant="outline"
          size="icon"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="h-12 w-12 border-2"
        >
          {isMobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </Button>
      </div>

      {/* Sidebar - Fixed positioning for desktop, overlay for mobile */}
      <div
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 xl:w-72 bg-white border-r border-gray-200 shadow-xl lg:shadow-none transform transition-all duration-300 ease-in-out",
          // Mobile behavior
          "lg:translate-x-0",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0",
        )}
      >
        <div className="flex flex-col h-full">
          {/* Header - Responsive padding and sizing */}
          <div className="flex items-center gap-3 p-4 lg:p-6 border-b bg-gradient-to-r from-blue-50 to-indigo-50">
            <div className="bg-blue-600 p-2 lg:p-2.5 rounded-lg shadow-md">
              <GraduationCap className="h-5 w-5 lg:h-6 lg:w-6 text-white" />
            </div>
            <div className="min-w-0 flex-1">
              <h1 className="font-bold text-base lg:text-lg text-gray-900 truncate">E-PKL by V0</h1>
              <p className="text-xs text-gray-600 truncate">Education Management</p>
            </div>
          </div>

          {/* User info - Improved responsive layout */}
          <div className="p-4 lg:p-4 border-b bg-gray-50">
            <div className="flex items-center gap-3">
              <Avatar className="h-12 w-12 lg:h-10 lg:w-10 border-2 border-white shadow-sm">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-indigo-600 text-white font-semibold">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm lg:text-sm text-gray-900 truncate">{user.name}</p>
                <p className="text-xs text-gray-600 truncate">{user.email}</p>
                <p className="text-xs text-blue-600 font-medium truncate mt-0.5">
                  {user.jurusan?.name} - {user.kelas?.name}
                </p>
              </div>
            </div>
          </div>

          {/* Navigation - Enhanced mobile experience */}
          <nav className="flex-1 p-3 lg:p-4 overflow-y-auto">
            <ul className="space-y-1 lg:space-y-2">
              {navigation.map((item) => {
                const isActive = pathname === item.href
                return (
                  <li key={item.name}>
                    <Link
                      href={item.href}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className={cn(
                        "flex items-center gap-3 px-4 py-3 lg:px-3 lg:py-2 rounded-xl text-sm font-medium transition-all duration-200 group",
                        isActive
                          ? "bg-gradient-to-r from-blue-500 to-indigo-600 text-white shadow-lg transform scale-[1.02]"
                          : "text-gray-700 hover:bg-blue-50 hover:text-blue-700 active:bg-blue-100",
                      )}
                    >
                      <item.icon
                        className={cn(
                          "h-5 w-5 transition-transform duration-200",
                          isActive ? "text-white" : "text-gray-500 group-hover:text-blue-600",
                          "group-hover:scale-110",
                        )}
                      />
                      <span className="truncate">{item.name}</span>
                      {isActive && <div className="ml-auto w-2 h-2 bg-white rounded-full shadow-sm" />}
                    </Link>
                  </li>
                )
              })}
            </ul>
          </nav>

          {/* Logout - Enhanced styling */}
          <div className="p-3 lg:p-4 border-t bg-gray-50">
            <Button
              variant="ghost"
              onClick={handleLogout}
              className="w-full justify-start gap-3 text-red-600 hover:text-red-700 hover:bg-red-50 active:bg-red-100 h-12 lg:h-10 rounded-xl font-medium transition-all duration-200"
            >
              <LogOut className="h-5 w-5" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile overlay - Improved interaction */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/60 backdrop-blur-sm z-40 lg:hidden transition-opacity duration-300"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}
    </>
  )
}
