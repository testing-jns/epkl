export interface ApiResponse<T> {
  success: boolean
  message: string
  data: T
  meta?: {
    total_row?: number
    total_page?: number
    current_page?: number
    total_item?: number
    next_page?: number | null
    prev_page?: number | null
  }
}

export interface Jurusan {
  id: number
  name: string
  created_at: string
  updated_at: string
}

export interface Kelas {
  id: number
  name: string
  m_jurusan_id: number
  other: string | null
  created_at: string
  updated_at: string
}

export interface Student {
  nisn: string
  email: string
  name: string
  m_jurusan_id: number
  m_kelas_id: number
  place_of_birth: string | null
  date_of_birth: string | null
  phone: string
  activated: boolean
  device_id: string
  m_dudi_id: number | null
  lat: string
  long: string
  semester: string
  year: string
  avatar: string
  created_at: string
  updated_at: string
  jurusan?: Jurusan
  kelas?: Kelas
  dudi?: Dudi
  bimbingan?: Bimbingan | null
}

export interface Dudi {
  id: number
  name: string
  address: string
  contact: string
  pic: string
  deleted_at: string | null
  logo: string | null
  created_at: string
  updated_at: string
}

export interface LoginResponse {
  token: string
  user: Student
}

export interface Attendance {
  id: number
  date: string
  check_in: string | null
  check_out: string | null
  description: string | null
  created_at: string
  updated_at: string
  nisn: string
}

export interface Journal {
  id: string
  siswa_nisn: string
  tanggal: string
  kegiatan: string
  target: string
  created_at: string
  updated_at: string
}

export interface Info {
  id: number
  title: string
  image: string | null
  created_at: string
  updated_at: string
}

export interface Bimbingan {
  id: number
  name: string
  email: string
  phone: string
  position: string
  created_at: string
  updated_at: string
}

// New types for Events and Auto Presence
export interface StudentEvent {
  code: string
  name: string
  message: string
}

export interface AutoPresenceSettings {
  code: string
  id: number
  nisn: string
  check_in_start: string
  check_in_end: string
  fix_check_in: string
  check_out_start: string
  check_out_end: string
  fix_check_out: string
  except_days?: string[]
}

export interface AutoPresenceRequest {
  CODE: string
  check_in_start: string
  check_in_end: string
  check_out_start: string
  check_out_end: string
  except_days: string[]
}
