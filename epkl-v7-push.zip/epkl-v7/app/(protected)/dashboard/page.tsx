"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import type { Attendance, Info } from "@/types/api"
import { Clock, CheckCircle, XCircle, BookOpen, Building2, AlertCircle, Eye, Zap, Settings } from "lucide-react"
import { format } from "date-fns"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import Link from "next/link"

// Import the InfoDetailDialog component
import { InfoDetailDialog } from "@/components/info-detail-dialog"
import { CompanySelectionDialog } from "@/components/company-selection-dialog"
import { EventsCard } from "@/components/events-card"

export default function DashboardPage() {
  const { user } = useAuth()
  const [todayAttendance, setTodayAttendance] = useState<Attendance | null>(null)
  const [infoList, setInfoList] = useState<Info[]>([])
  const [autoPresenceEnabled, setAutoPresenceEnabled] = useState(false)
  const [isCheckingIn, setIsCheckingIn] = useState(false)
  const [isCheckingOut, setIsCheckingOut] = useState(false)
  const [attendanceMessage, setAttendanceMessage] = useState("")
  const [showCheckInConfirm, setShowCheckInConfirm] = useState(false)
  const [showCheckOutConfirm, setShowCheckOutConfirm] = useState(false)
  const [showCompanySelection, setShowCompanySelection] = useState(false)

  // State for the selected info ID and dialog open state
  const [selectedInfoId, setSelectedInfoId] = useState<number | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)

  const today = format(new Date(), "MM-dd-yyyy")

  useEffect(() => {
    if (user) {
      fetchTodayAttendance()
      fetchInfo()
      checkAutoPresenceStatus()

      // Show company selection dialog if user doesn't have a company
      if (!user.dudi) {
        setShowCompanySelection(true)
      }
    }
  }, [user])

  const fetchTodayAttendance = async () => {
    if (!user) return

    try {
      const response = await apiService.getAttendanceList(user.nisn, today, today)
      if (response.success && response.data.length > 0) {
        setTodayAttendance(response.data[0])
      }
    } catch (error) {
      console.error("Error fetching attendance:", error)
    }
  }

  const fetchInfo = async () => {
    try {
      const response = await apiService.getInfo()
      if (response.success) {
        setInfoList(response.data.info)
      }
    } catch (error) {
      console.error("Error fetching info:", error)
    }
  }

  const checkAutoPresenceStatus = async () => {
    if (!user) return

    try {
      const response = await apiService.getAutoPresenceStatus(user.nisn)
      if (response.success) {
        const autoPresenceSettings = response.data.find((s) => s.code === "AUTOPRESENSI")
        setAutoPresenceEnabled(!!autoPresenceSettings)
      }
    } catch (error) {
      console.error("Error checking auto presence status:", error)
    }
  }

  const handleCheckIn = async () => {
    if (!user) return

    setIsCheckingIn(true)
    try {
      const response = await apiService.checkIn(user.nisn, today)
      if (response.success) {
        setTodayAttendance(response.data)
        setAttendanceMessage("Successfully checked in!")
        setTimeout(() => setAttendanceMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error checking in:", error)
    }
    setIsCheckingIn(false)
    setShowCheckInConfirm(false)
  }

  const handleCheckOut = async () => {
    if (!user) return

    setIsCheckingOut(true)
    try {
      const response = await apiService.checkOut(user.nisn, today)
      if (response.success) {
        setTodayAttendance(response.data)
        setAttendanceMessage("Successfully checked out!")
        setTimeout(() => setAttendanceMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error checking out:", error)
    }
    setIsCheckingOut(false)
    setShowCheckOutConfirm(false)
  }

  const getAttendanceStatus = () => {
    if (!todayAttendance) {
      return {
        message: "You haven't checked in today",
        variant: "destructive" as const,
        icon: <AlertCircle className="h-4 w-4" />,
        canCheckIn: true,
        canCheckOut: false,
      }
    }

    if (todayAttendance.check_in && !todayAttendance.check_out) {
      return {
        message: "You haven't checked out today",
        variant: "default" as const,
        icon: <Clock className="h-4 w-4" />,
        canCheckIn: false,
        canCheckOut: true,
      }
    }

    if (todayAttendance.check_in && todayAttendance.check_out) {
      return {
        message: "You have completed attendance for today",
        variant: "default" as const,
        icon: <CheckCircle className="h-4 w-4" />,
        canCheckIn: false,
        canCheckOut: false,
      }
    }

    return {
      message: "Unknown attendance status",
      variant: "default" as const,
      icon: <XCircle className="h-4 w-4" />,
      canCheckIn: false,
      canCheckOut: false,
    }
  }

  const attendanceStatus = getAttendanceStatus()

  if (!user) {
    return <div>Loading...</div>
  }

  // Function to handle clicking on an info item
  const handleInfoClick = (infoId: number) => {
    console.log("Clicking info item with ID:", infoId) // Debug log
    setSelectedInfoId(infoId)
    setIsDetailDialogOpen(true)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Welcome back, {user.name}!</h1>
          <p className="text-muted-foreground">
            {user.jurusan?.name} - {user.kelas?.name}
          </p>
        </div>
        <Badge variant="secondary" className="text-sm">
          Semester {user.semester} - {user.year}
        </Badge>
      </div>

      {attendanceMessage && (
        <Alert>
          <CheckCircle className="h-4 w-4" />
          <AlertDescription>{attendanceMessage}</AlertDescription>
        </Alert>
      )}

      {/* Show alert if no company assigned */}
      {!user.dudi && (
        <Alert>
          <Building2 className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span>You haven't been assigned to an internship company yet.</span>
            <Button variant="outline" size="sm" onClick={() => setShowCompanySelection(true)} className="ml-4">
              Select Company
            </Button>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Attendance Card */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="h-5 w-5" />
              Today's Attendance
              {/* Auto Presence Status Badge */}
              <Badge
                variant={autoPresenceEnabled ? "default" : "secondary"}
                className={`ml-auto text-xs ${autoPresenceEnabled ? "bg-green-100 text-green-800 border-green-300" : ""}`}
              >
                <Zap className="h-3 w-3 mr-1" />
                {autoPresenceEnabled ? "Auto ON" : "Manual"}
              </Badge>
            </CardTitle>
            <CardDescription className="flex items-center justify-between">
              <span>{format(new Date(), "EEEE, MMMM d, yyyy")}</span>
              <Link href="/settings">
                <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                  <Settings className="h-3 w-3 mr-1" />
                  Settings
                </Button>
              </Link>
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert variant={attendanceStatus.variant}>
              {attendanceStatus.icon}
              <AlertDescription>{attendanceStatus.message}</AlertDescription>
            </Alert>

            {/* Auto Presence Info */}
            {autoPresenceEnabled && (
              <Alert className="border-green-200 bg-green-50">
                <Zap className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  <strong>Auto Presence is enabled!</strong> Your attendance will be tracked automatically based on your
                  configured schedule.
                </AlertDescription>
              </Alert>
            )}

            {todayAttendance && (
              <div className="space-y-2 text-sm">
                {todayAttendance.check_in && (
                  <div className="flex justify-between">
                    <span>Check In:</span>
                    <span className="font-medium">
                      {format(new Date(Number.parseInt(todayAttendance.check_in) * 1000), "HH:mm:ss")}
                    </span>
                  </div>
                )}
                {todayAttendance.check_out && (
                  <div className="flex justify-between">
                    <span>Check Out:</span>
                    <span className="font-medium">
                      {format(new Date(Number.parseInt(todayAttendance.check_out) * 1000), "HH:mm:ss")}
                    </span>
                  </div>
                )}
              </div>
            )}

            <div className="flex gap-2">
              {attendanceStatus.canCheckIn && (
                <>
                  <Button onClick={() => setShowCheckInConfirm(true)} disabled={isCheckingIn} className="flex-1">
                    Check In
                  </Button>

                  <AlertDialog open={showCheckInConfirm} onOpenChange={setShowCheckInConfirm}>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Check In</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to check in? This will mark the start of your work day.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleCheckIn} disabled={isCheckingIn}>
                          {isCheckingIn ? "Checking In..." : "Yes, Check In"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
              {attendanceStatus.canCheckOut && (
                <>
                  <Button
                    onClick={() => setShowCheckOutConfirm(true)}
                    disabled={isCheckingOut}
                    variant="outline"
                    className="flex-1"
                  >
                    Check Out
                  </Button>

                  <AlertDialog open={showCheckOutConfirm} onOpenChange={setShowCheckOutConfirm}>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Confirm Check Out</AlertDialogTitle>
                        <AlertDialogDescription>
                          Are you sure you want to check out? This will mark the end of your work day.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={handleCheckOut} disabled={isCheckingOut}>
                          {isCheckingOut ? "Checking Out..." : "Yes, Check Out"}
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Profile Summary */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Profile Summary
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>NISN:</span>
              <span className="font-medium">{user.nisn}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Email:</span>
              <span className="font-medium">{user.email}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Phone:</span>
              <span className="font-medium">{user.phone}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Status:</span>
              <Badge variant={user.activated ? "default" : "secondary"}>
                {user.activated ? "Activated" : "Pending"}
              </Badge>
            </div>
          </CardContent>
        </Card>

        {/* Company Info */}
        {user.dudi ? (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Internship Company
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Company Logo */}
              {user.dudi.logo && (
                <div className="flex justify-center mb-4">
                  <img
                    src={`http://epkl.smk2-yk.sch.id${user.dudi.logo}`}
                    alt={`${user.dudi.name} logo`}
                    className="h-16 w-16 object-contain border-2 border-gray-200 rounded-lg p-2 bg-white"
                  />
                </div>
              )}

              <div>
                <p className="font-medium">{user.dudi.name}</p>
                <p className="text-sm text-muted-foreground">{user.dudi.address}</p>
              </div>
              {user.dudi.pic && user.dudi.pic !== "-" && (
                <div className="text-sm">
                  <span className="text-muted-foreground">PIC: </span>
                  <span className="font-medium">{user.dudi.pic}</span>
                </div>
              )}
              {user.dudi.contact && user.dudi.contact !== "0" && (
                <div className="text-sm">
                  <span className="text-muted-foreground">Contact: </span>
                  <span className="font-medium">{user.dudi.contact}</span>
                </div>
              )}
            </CardContent>
          </Card>
        ) : (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Building2 className="h-5 w-5" />
                Internship Company
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center py-6">
              <div className="text-muted-foreground">
                <Building2 className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm mb-3">No company assigned</p>
                <Button variant="outline" size="sm" onClick={() => setShowCompanySelection(true)}>
                  Select Company
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Events Section */}
      <EventsCard />

      {/* Information Section */}
      {infoList.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Latest Information</CardTitle>
            <CardDescription>Important announcements and updates - Click to view details</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {infoList.slice(0, 3).map((info) => (
                <div
                  key={info.id}
                  className="flex items-start gap-3 p-4 border rounded-lg cursor-pointer hover:bg-gray-50 hover:border-orange-300 transition-all duration-200 group"
                  onClick={() => handleInfoClick(info.id)}
                >
                  {info.image ? (
                    <img
                      src={`http://epkl.smk2-yk.sch.id${info.image}`}
                      alt={info.title}
                      className="w-12 h-12 object-cover rounded"
                    />
                  ) : (
                    <div className="w-12 h-12 bg-orange-100 rounded flex items-center justify-center">
                      <BookOpen className="h-6 w-6 text-orange-600" />
                    </div>
                  )}
                  <div className="flex-1">
                    <h4 className="font-medium group-hover:text-orange-600 transition-colors">{info.title}</h4>
                    <p className="text-sm text-muted-foreground">{format(new Date(info.created_at), "MMM d, yyyy")}</p>
                  </div>
                  <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                    <Eye className="h-4 w-4 text-orange-600" />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* InfoDetailDialog component */}
      <InfoDetailDialog
        infoId={selectedInfoId}
        isOpen={isDetailDialogOpen}
        onClose={() => {
          setIsDetailDialogOpen(false)
          setSelectedInfoId(null)
        }}
      />

      {/* Company Selection Dialog */}
      <CompanySelectionDialog isOpen={showCompanySelection} onClose={() => setShowCompanySelection(false)} />
    </div>
  )
}
