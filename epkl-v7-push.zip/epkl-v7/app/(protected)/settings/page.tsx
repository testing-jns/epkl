"use client"

import { AutoPresenceSettingsComponent } from "@/components/auto-presence-settings"
import { EventsCard } from "@/components/events-card"
import { Settings, Zap, Sparkles } from "lucide-react"

export default function SettingsPage() {
  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white/20 p-3 rounded-xl">
              <Settings className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold">Settings & Events</h1>
              <p className="text-white/90 text-lg">Manage your preferences and stay updated with events</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              <span className="text-white/90">Auto Presence</span>
            </div>
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              <span className="text-white/90">Events & Announcements</span>
            </div>
          </div>
        </div>
      </div>

      {/* Events Section */}
      <EventsCard />

      {/* Auto Presence Settings */}
      <AutoPresenceSettingsComponent />
    </div>
  )
}
