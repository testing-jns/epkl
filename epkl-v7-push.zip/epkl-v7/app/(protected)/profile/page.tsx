"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useAuth } from "@/contexts/auth-context"
import { apiService } from "@/lib/api"
import {
  User,
  Camera,
  Building2,
  Phone,
  Mail,
  Calendar,
  GraduationCap,
  Edit,
  MapPin,
  Users,
  Save,
  X,
} from "lucide-react"
import { format } from "date-fns"

export default function ProfilePage() {
  const { user, updateUser, refreshUserProfile } = useAuth()
  const [isUploading, setIsUploading] = useState(false)
  const [message, setMessage] = useState("")
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [editForm, setEditForm] = useState({
    name: user?.name || "",
    phone: user?.phone || "",
  })
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)

  useEffect(() => {
    if (user) {
      refreshUserProfile()
    }
  }, [])

  const handleAvatarClick = () => {
    fileInputRef.current?.click()
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file || !user) return

    // Validate file type
    if (!file.type.startsWith("image/")) {
      setMessage("Please select a valid image file")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setMessage("File size must be less than 5MB")
      setTimeout(() => setMessage(""), 3000)
      return
    }

    setIsUploading(true)
    try {
      const response = await apiService.updateAvatar(user.nisn, file)
      if (response.success) {
        updateUser(response.data)
        setMessage("Avatar updated successfully!")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error updating avatar:", error)
      setMessage("Error updating avatar")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsUploading(false)
  }

  const handleEditSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!user) return

    setIsSubmitting(true)
    try {
      const response = await apiService.updateProfile(user.nisn, {
        name: editForm.name,
        phone: editForm.phone,
      })

      if (response.success) {
        updateUser(response.data)
        setMessage("Profile updated successfully!")
        setIsEditDialogOpen(false)
      } else {
        setMessage("Error updating profile")
      }
    } catch (error) {
      console.error("Error updating profile:", error)
      setMessage("Error updating profile")
    }
    setIsSubmitting(false)
    setTimeout(() => setMessage(""), 3000)
  }

  if (!user) {
    return <div>Loading...</div>
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-purple-600 via-blue-600 to-indigo-700 p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24"></div>

        <div className="relative z-10 flex items-center justify-between">
          <div className="flex items-center gap-6">
            <div className="relative">
              <Avatar className="h-24 w-24 border-4 border-white/30">
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="bg-white/20 text-white text-2xl">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
            <div>
              <h1 className="text-4xl font-bold">{user.name}</h1>
              <p className="text-white/90 text-lg">{user.email}</p>
              <div className="flex items-center gap-3 mt-2">
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  <GraduationCap className="h-3 w-3 mr-1" />
                  {user.nisn}
                </Badge>
                <Badge
                  variant="secondary"
                  className={`${user.activated ? "bg-green-500/20 text-green-100 border-green-300/30" : "bg-yellow-500/20 text-yellow-100 border-yellow-300/30"}`}
                >
                  {user.activated ? "Activated" : "Pending"}
                </Badge>
              </div>
            </div>
          </div>

          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
            <DialogTrigger asChild>
              <Button variant="secondary" className="bg-white/20 text-white border-white/30 hover:bg-white/30">
                <Edit className="h-4 w-4 mr-2" />
                Edit Profile
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle>Edit Profile</DialogTitle>
                <DialogDescription>Update your personal information</DialogDescription>
              </DialogHeader>
              <form onSubmit={handleEditSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="edit-name">Full Name</Label>
                  <Input
                    id="edit-name"
                    value={editForm.name}
                    onChange={(e) => setEditForm((prev) => ({ ...prev, name: e.target.value }))}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="edit-phone">Phone</Label>
                  <Input
                    id="edit-phone"
                    value={editForm.phone}
                    onChange={(e) => setEditForm((prev) => ({ ...prev, phone: e.target.value }))}
                    required
                  />
                </div>
                <div className="flex gap-2">
                  <Button type="submit" className="flex-1" disabled={isSubmitting}>
                    <Save className="h-4 w-4 mr-2" />
                    {isSubmitting ? "Saving..." : "Save Changes"}
                  </Button>
                  <Button type="button" variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {message && (
        <Alert>
          <AlertDescription>{message}</AlertDescription>
        </Alert>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Profile Picture Card */}
        <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="bg-purple-500 p-2 rounded-lg">
                <User className="h-5 w-5 text-white" />
              </div>
              Profile Picture
            </CardTitle>
            <CardDescription>Click on the avatar to update your profile picture</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-6">
            <div className="relative group">
              <Avatar
                className="h-40 w-40 cursor-pointer transition-transform group-hover:scale-105"
                onClick={handleAvatarClick}
              >
                <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
                <AvatarFallback className="text-3xl bg-gradient-to-br from-purple-100 to-purple-200 text-purple-700">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div
                className="absolute bottom-2 right-2 bg-purple-600 rounded-full p-3 cursor-pointer shadow-lg hover:bg-purple-700 transition-colors"
                onClick={handleAvatarClick}
              >
                <Camera className="h-5 w-5 text-white" />
              </div>
            </div>

            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleFileChange} className="hidden" />

            <Button
              onClick={handleAvatarClick}
              disabled={isUploading}
              variant="outline"
              className="w-full h-12 border-2 border-purple-200 hover:border-purple-300"
            >
              {isUploading ? "Uploading..." : "Change Avatar"}
            </Button>

            <p className="text-xs text-gray-500 text-center">Supported formats: JPG, PNG, GIF (max 5MB)</p>
          </CardContent>
        </Card>

        {/* Personal Information */}
        <Card className="lg:col-span-2 border-0 shadow-xl bg-gradient-to-br from-white to-blue-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-3">
              <div className="bg-blue-500 p-2 rounded-lg">
                <User className="h-5 w-5 text-white" />
              </div>
              Personal Information
            </CardTitle>
            <CardDescription>Your basic profile information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-6">
                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <User className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Full Name</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.name}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">NISN</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.nisn}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Mail className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Email</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.email}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Phone className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Phone</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.phone}</p>
                </div>
              </div>

              <div className="space-y-6">
                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Major</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.jurusan?.name || "Not specified"}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <GraduationCap className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Class</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">{user.kelas?.name || "Not specified"}</p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <Calendar className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Semester & Year</span>
                  </div>
                  <p className="text-lg font-medium text-gray-900">
                    Semester {user.semester} - {user.year}
                  </p>
                </div>

                <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                  <div className="flex items-center gap-3 mb-2">
                    <User className="h-5 w-5 text-blue-600" />
                    <span className="font-semibold text-blue-900">Account Status</span>
                  </div>
                  <Badge variant={user.activated ? "default" : "secondary"} className="text-base px-3 py-1">
                    {user.activated ? "Activated" : "Pending Activation"}
                  </Badge>
                </div>
              </div>
            </div>

            {(user.place_of_birth || user.date_of_birth) && (
              <div className="pt-6 border-t-2 border-blue-100">
                <h4 className="font-bold text-xl text-blue-900 mb-4">Birth Information</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {user.place_of_birth && (
                    <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                      <p className="font-semibold text-blue-900 mb-1">Place of Birth</p>
                      <p className="text-lg font-medium text-gray-900">{user.place_of_birth}</p>
                    </div>
                  )}
                  {user.date_of_birth && (
                    <div className="bg-white p-4 rounded-xl border-2 border-blue-100">
                      <p className="font-semibold text-blue-900 mb-1">Date of Birth</p>
                      <p className="text-lg font-medium text-gray-900">
                        {format(new Date(user.date_of_birth), "MMMM d, yyyy")}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Company Information */}
        {user.dudi ? (
          <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-green-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="bg-green-500 p-2 rounded-lg">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                Internship Company
              </CardTitle>
              <CardDescription>Information about your assigned internship company</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-white p-6 rounded-xl border-2 border-green-100">
                <h3 className="font-bold text-2xl text-green-900 mb-4">{user.dudi.name}</h3>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <MapPin className="h-5 w-5 text-green-600 mt-1 flex-shrink-0" />
                    <div>
                      <p className="font-semibold text-green-900">Address</p>
                      <p className="text-gray-700">{user.dudi.address}</p>
                    </div>
                  </div>

                  {user.dudi.pic && user.dudi.pic !== "-" && (
                    <div className="flex items-start gap-3">
                      <Users className="h-5 w-5 text-green-600 mt-1" />
                      <div>
                        <p className="font-semibold text-green-900">Person in Charge</p>
                        <p className="text-gray-700">{user.dudi.pic}</p>
                      </div>
                    </div>
                  )}

                  {user.dudi.contact && user.dudi.contact !== "0" && (
                    <div className="flex items-start gap-3">
                      <Phone className="h-5 w-5 text-green-600 mt-1" />
                      <div>
                        <p className="font-semibold text-green-900">Contact</p>
                        <p className="text-gray-700">{user.dudi.contact}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-3">
                    <Calendar className="h-5 w-5 text-green-600 mt-1" />
                    <div>
                      <p className="font-semibold text-green-900">Registration Date</p>
                      <p className="text-gray-700">{format(new Date(user.dudi.created_at), "MMMM d, yyyy")}</p>
                    </div>
                  </div>
                </div>

                {user.dudi.logo && (
                  <div className="mt-6 pt-6 border-t border-green-200">
                    <p className="font-semibold text-green-900 mb-3">Company Logo</p>
                    <img
                      src={`http://epkl.smk2-yk.sch.id${user.dudi.logo}`}
                      alt={`${user.dudi.name} logo`}
                      className="h-20 object-contain border-2 border-green-200 rounded-lg p-2"
                    />
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-orange-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="bg-orange-500 p-2 rounded-lg">
                  <Building2 className="h-5 w-5 text-white" />
                </div>
                No Company Assigned
              </CardTitle>
              <CardDescription>You haven't been assigned to an internship company yet</CardDescription>
            </CardHeader>
            <CardContent className="text-center py-8">
              <div className="bg-orange-100 p-6 rounded-xl">
                <Building2 className="h-16 w-16 text-orange-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-orange-900 mb-2">No Internship Company</h3>
                <p className="text-orange-700 mb-4">
                  You haven't been assigned to an internship company yet. Please contact your administrator or wait for
                  assignment.
                </p>
                <Badge variant="outline" className="border-orange-300 text-orange-700">
                  Pending Assignment
                </Badge>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Guidance Information */}
        {user.bimbingan && (
          <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-purple-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <div className="bg-purple-500 p-2 rounded-lg">
                  <Users className="h-5 w-5 text-white" />
                </div>
                Guidance Counselor
              </CardTitle>
              <CardDescription>Your assigned guidance counselor information</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-white p-6 rounded-xl border-2 border-purple-100">
                <h3 className="font-bold text-2xl text-purple-900 mb-2">{user.bimbingan.name}</h3>
                <p className="text-purple-600 font-medium mb-4">{user.bimbingan.position}</p>

                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Mail className="h-5 w-5 text-purple-600" />
                    <div>
                      <p className="font-semibold text-purple-900">Email</p>
                      <p className="text-gray-700">{user.bimbingan.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-purple-600" />
                    <div>
                      <p className="font-semibold text-purple-900">Phone</p>
                      <p className="text-gray-700">{user.bimbingan.phone}</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Account Information */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3">
            <div className="bg-gray-500 p-2 rounded-lg">
              <User className="h-5 w-5 text-white" />
            </div>
            Account Information
          </CardTitle>
          <CardDescription>Technical details about your account</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="bg-white p-4 rounded-xl border-2 border-gray-100">
              <p className="font-semibold text-gray-900 mb-1">Device ID</p>
              <p className="font-mono text-sm text-gray-700 break-all">{user.device_id}</p>
            </div>

            <div className="bg-white p-4 rounded-xl border-2 border-gray-100">
              <p className="font-semibold text-gray-900 mb-1">Account Created</p>
              <p className="text-gray-700">{format(new Date(user.created_at), "MMM d, yyyy")}</p>
              <p className="text-sm text-gray-500">{format(new Date(user.created_at), "HH:mm")}</p>
            </div>

            <div className="bg-white p-4 rounded-xl border-2 border-gray-100">
              <p className="font-semibold text-gray-900 mb-1">Last Updated</p>
              <p className="text-gray-700">{format(new Date(user.updated_at), "MMM d, yyyy")}</p>
              <p className="text-sm text-gray-500">{format(new Date(user.updated_at), "HH:mm")}</p>
            </div>

            {user.lat && user.long && (
              <div className="bg-white p-4 rounded-xl border-2 border-gray-100">
                <p className="font-semibold text-gray-900 mb-1">Location</p>
                <p className="font-mono text-sm text-gray-700">
                  {user.lat}, {user.long}
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
