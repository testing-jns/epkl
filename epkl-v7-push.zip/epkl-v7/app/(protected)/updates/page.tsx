"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import {
  Sparkles,
  Zap,
  Bug,
  Building2,
  BookOpen,
  Clock,
  AlertTriangle,
  Star,
  Gift,
  Rocket,
  Heart,
  Code,
  Users,
} from "lucide-react"
import { format } from "date-fns"

export default function UpdatesPage() {
  const updates = [
    {
      version: "1.1.1",
      date: "2025-07-05",
      type: "Feature Update",
      badge: "Latest - Experimental",
      badgeColor: "bg-green-100 text-green-800 border-green-300",
      features: [
        {
          icon: <Zap className="h-5 w-5 text-blue-600" />,
          title: "Auto Presence Feature",
          description:
            "Fitur auto presensi yang bisa di-setting di menu Settings. Tinggal atur range jam check-in & check-out, dan bisa dimatikan kapan saja.",
          note: "Tapi jangan dibuat untuk nakal, ygy. Ini juga masih experimental 😊",
        },
      ],
      bugFixes: [
        {
          icon: <Building2 className="h-5 w-5 text-green-600" />,
          title: "Internship Company Selection",
          description:
            "Memperbaiki bug pada proses pemilihan perusahaan internship untuk pengalaman yang lebih lancar.",
        },
      ],
      improvements: [],
    },
    {
      version: "1.0.0",
      date: "2027-01-01",
      type: "Initial Release",
      badge: "Stable",
      badgeColor: "bg-blue-100 text-blue-800 border-blue-300",
      features: [
        {
          icon: <Clock className="h-5 w-5 text-blue-600" />,
          title: "Attendance System",
          description: "Sistem presensi dengan check-in dan check-out, tracking lokasi, dan history lengkap.",
        },
        {
          icon: <BookOpen className="h-5 w-5 text-green-600" />,
          title: "Digital Journal",
          description: "Jurnal digital untuk mencatat kegiatan harian dan target dengan interface yang user-friendly.",
        },
        {
          icon: <Building2 className="h-5 w-5 text-orange-600" />,
          title: "Company Integration",
          description: "Integrasi dengan perusahaan internship, informasi mentor, dan data perusahaan lengkap.",
        },
        {
          icon: <Users className="h-5 w-5 text-indigo-600" />,
          title: "Profile Management",
          description: "Manajemen profil lengkap dengan upload avatar, edit data, dan informasi akademik.",
        },
      ],
      bugFixes: [],
      improvements: [],
    },
  ]

  const getTypeColor = (type: string) => {
    switch (type) {
      case "Major Update":
        return "from-purple-500 to-indigo-500"
      case "Feature Update":
        return "from-green-500 to-teal-500"
      case "Initial Release":
        return "from-blue-500 to-cyan-500"
      default:
        return "from-gray-500 to-gray-600"
    }
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 p-8 text-white">
        <div className="absolute inset-0 bg-black/20"></div>
        <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-32 translate-x-32"></div>
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/5 rounded-full translate-y-24 -translate-x-24"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-4">
            <div className="bg-white/20 p-3 rounded-xl">
              <Rocket className="h-8 w-8 text-white" />
            </div>
            <div>
              <h1 className="text-4xl font-bold">Updates & Changelog</h1>
              <p className="text-white/90 text-lg">Track all the latest features, improvements, and bug fixes</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              <span className="text-white/90">New Features</span>
            </div>
            <div className="flex items-center gap-2">
              <Bug className="h-4 w-4" />
              <span className="text-white/90">Bug Fixes</span>
            </div>
            <div className="flex items-center gap-2">
              <Star className="h-4 w-4" />
              <span className="text-white/90">Improvements</span>
            </div>
          </div>
        </div>
      </div>

      {/* Updates Timeline */}
      <div className="space-y-8">
        {updates.map((update, index) => (
          <Card key={update.version} className="border-0 shadow-xl bg-gradient-to-br from-white to-gray-50">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`bg-gradient-to-r ${getTypeColor(update.type)} p-3 rounded-xl`}>
                    <Code className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <CardTitle className="text-2xl">Version {update.version}</CardTitle>
                    <CardDescription className="text-base">
                      {format(new Date(update.date), "MMMM d, yyyy")} • {update.type}
                    </CardDescription>
                  </div>
                </div>
                <Badge className={update.badgeColor}>{update.badge}</Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* New Features */}
              {update.features.length > 0 && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <Sparkles className="h-5 w-5 text-blue-600" />
                    <h3 className="text-lg font-semibold text-blue-900">✨ New Features</h3>
                  </div>
                  <div className="space-y-4">
                    {update.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="bg-blue-50 p-4 rounded-xl border border-blue-200">
                        <div className="flex items-start gap-4">
                          <div className="bg-blue-100 p-2 rounded-lg flex-shrink-0">{feature.icon}</div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-blue-900 mb-2">{feature.title}</h4>
                            <p className="text-blue-800 leading-relaxed">{feature.description}</p>
                            {feature.note && (
                              <div className="mt-3 flex items-center gap-2 text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                                <AlertTriangle className="h-4 w-4 flex-shrink-0" />
                                <span className="text-sm font-medium">{feature.note}</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Bug Fixes */}
              {update.bugFixes.length > 0 && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <Bug className="h-5 w-5 text-green-600" />
                    <h3 className="text-lg font-semibold text-green-900">🐛 Bug Fixes</h3>
                  </div>
                  <div className="space-y-3">
                    {update.bugFixes.map((fix, fixIndex) => (
                      <div key={fixIndex} className="bg-green-50 p-4 rounded-xl border border-green-200">
                        <div className="flex items-start gap-4">
                          <div className="bg-green-100 p-2 rounded-lg flex-shrink-0">{fix.icon}</div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-green-900 mb-1">{fix.title}</h4>
                            <p className="text-green-800 leading-relaxed">{fix.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Improvements */}
              {update.improvements.length > 0 && (
                <div>
                  <div className="flex items-center gap-3 mb-4">
                    <Star className="h-5 w-5 text-yellow-600" />
                    <h3 className="text-lg font-semibold text-yellow-900">⭐ Improvements</h3>
                  </div>
                  <div className="space-y-3">
                    {update.improvements.map((improvement, improvementIndex) => (
                      <div key={improvementIndex} className="bg-yellow-50 p-4 rounded-xl border border-yellow-200">
                        <div className="flex items-start gap-4">
                          <div className="bg-yellow-100 p-2 rounded-lg flex-shrink-0">{improvement.icon}</div>
                          <div className="flex-1">
                            <h4 className="font-semibold text-yellow-900 mb-1">{improvement.title}</h4>
                            <p className="text-yellow-800 leading-relaxed">{improvement.description}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {index < updates.length - 1 && <Separator className="mt-6" />}
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Footer */}
      <Card className="border-0 shadow-xl bg-gradient-to-br from-purple-50 to-pink-50">
        <CardContent className="p-8 text-center">
          <div className="flex justify-center mb-4">
            <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-4 rounded-full">
              <Heart className="h-8 w-8 text-white" />
            </div>
          </div>
          <h3 className="text-2xl font-bold text-gray-900 mb-2">Thank You!</h3>
          <p className="text-gray-600 leading-relaxed max-w-2xl mx-auto">
            Terima kasih sudah menggunakan Student Portal! Kami terus berusaha memberikan pengalaman terbaik untuk
            mendukung perjalanan internship kalian. Keep learning and growing! 🚀
          </p>
          <div className="mt-6 flex justify-center gap-2">
            <Badge className="bg-purple-100 text-purple-800 border-purple-300">Made with ❤️</Badge>
            <Badge className="bg-pink-100 text-pink-800 border-pink-300">by v0 & jns23</Badge>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
