"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  GraduationCap,
  Clock,
  BookOpen,
  Users,
  Building2,
  CheckCircle,
  Star,
  ArrowRight,
  Smartphone,
  Shield,
  Zap,
  BarChart3,
  Award,
  TrendingUp,
  Monitor,
  Tablet,
  Eye,
} from "lucide-react"

export default function HomePage() {
  const [activeFeature, setActiveFeature] = useState(0)
  const [activeScreenshot, setActiveScreenshot] = useState(0)

  const features = [
    {
      icon: <Clock className="h-8 w-8" />,
      title: "Smart Attendance",
      description: "Real-time check-in/check-out with location tracking and automated reporting",
      color: "from-blue-500 to-blue-600",
    },
    {
      icon: <BookOpen className="h-8 w-8" />,
      title: "Digital Journal",
      description: "Track daily activities, set targets, and monitor progress with ease",
      color: "from-purple-500 to-purple-600",
    },
    {
      icon: <Building2 className="h-8 w-8" />,
      title: "Company Integration",
      description: "Seamless connection with internship companies and mentors",
      color: "from-green-500 to-green-600",
    },
    {
      icon: <BarChart3 className="h-8 w-8" />,
      title: "Analytics Dashboard",
      description: "Comprehensive insights into your academic and internship performance",
      color: "from-orange-500 to-orange-600",
    },
  ]

  const screenshots = [
    {
      title: "Dashboard Overview",
      description: "Clean and intuitive dashboard with all your important information at a glance",
      image: "/placeholder.svg?height=600&width=800",
      category: "Dashboard",
    },
    {
      title: "Attendance Tracking",
      description: "Easy check-in/check-out with real-time status and history tracking",
      image: "/placeholder.svg?height=600&width=800",
      category: "Attendance",
    },
    {
      title: "Digital Journal",
      description: "Beautiful journal interface for recording daily activities and targets",
      image: "/placeholder.svg?height=600&width=800",
      category: "Journal",
    },
    {
      title: "Profile Management",
      description: "Comprehensive profile page with company information and personal details",
      image: "/placeholder.svg?height=600&width=800",
      category: "Profile",
    },
    {
      title: "Information Center",
      description: "Stay updated with latest announcements and important information",
      image: "/placeholder.svg?height=600&width=800",
      category: "Information",
    },
    {
      title: "Mobile Experience",
      description: "Fully responsive design that works perfectly on all devices",
      image: "/placeholder.svg?height=600&width=400",
      category: "Mobile",
    },
  ]

  const stats = [
    { number: "1000+", label: "Active Students", icon: <Users className="h-6 w-6" /> },
    { number: "50+", label: "Partner Companies", icon: <Building2 className="h-6 w-6" /> },
    { number: "99.9%", label: "Uptime", icon: <Shield className="h-6 w-6" /> },
    { number: "24/7", label: "Support", icon: <Clock className="h-6 w-6" /> },
  ]

  const benefits = [
    {
      icon: <Smartphone className="h-6 w-6" />,
      title: "No Ribet",
      description: "Simple and intuitive interface - everything just works without complications",
    },
    {
      icon: <Shield className="h-6 w-6" />,
      title: 'No Lokasi"an',
      description: "Smart location handling that works everywhere without GPS issues",
    },
    {
      icon: <Zap className="h-6 w-6" />,
      title: "No Force Close",
      description: "Stable and reliable - built to run smoothly without crashes",
    },
    {
      icon: <Award className="h-6 w-6" />,
      title: "Industry Standard",
      description: "Built following best practices and educational standards",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-white">
      {/* Navigation */}
      <nav className="bg-white/80 backdrop-blur-md border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-3">
              <div className="bg-blue-600 p-2 rounded-lg">
                <GraduationCap className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="font-bold text-xl">Student Portal</h1>
                <p className="text-xs text-gray-600">Education Management</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link href="/login">
                <Button variant="ghost">Sign In</Button>
              </Link>
              <Link href="/register">
                <Button>Get Started</Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-600/10 via-purple-600/10 to-pink-600/10"></div>
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl -translate-y-48 translate-x-48"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl translate-y-48 -translate-x-48"></div>

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <Badge className="bg-blue-100 text-blue-800 border-blue-200">
                  <Star className="h-3 w-3 mr-1" />
                  Next-Gen Education Platform
                </Badge>
                <h1 className="text-5xl lg:text-6xl font-bold leading-tight">
                  Transform Your
                  <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                    {" "}
                    Learning Journey
                  </span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Experience the future of educational management with our comprehensive student portal.
                  <span className="font-semibold text-blue-600"> No ribet, no lokasi"an, no force close!</span>
                  Track attendance, manage journals, and connect with industry partners seamlessly.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/register">
                  <Button
                    size="lg"
                    className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 h-14 px-8 text-lg"
                  >
                    Start Your Journey
                    <ArrowRight className="h-5 w-5 ml-2" />
                  </Button>
                </Link>
                <Link href="/login">
                  <Button variant="outline" size="lg" className="h-14 px-8 text-lg border-2">
                    Sign In
                  </Button>
                </Link>
              </div>

              <div className="flex items-center gap-8 pt-4">
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-600">No Ribet</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-600">No Lokasi"an</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <span className="text-gray-600">No Force Close</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <div className="relative bg-white rounded-3xl shadow-2xl p-8 border">
                <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-purple-500/10 rounded-3xl"></div>
                <div className="relative">
                  <img
                    src="/images/hero-comparison.png"
                    alt="Student Portal vs Traditional Systems"
                    className="w-full h-auto rounded-2xl"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-2xl"></div>
                </div>
              </div>
              <div className="absolute -bottom-6 -right-6 bg-green-500 text-white p-4 rounded-2xl shadow-lg">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-6 w-6" />
                  <div>
                    <p className="font-bold">+1000 AURA</p>
                    <p className="text-sm opacity-90">Productivity Boost</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <div className="text-blue-600">{stat.icon}</div>
                </div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.number}</div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Screenshots Section */}
      <section className="py-20 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-indigo-100 text-indigo-800 border-indigo-200 mb-4">
              <Eye className="h-3 w-3 mr-1" />
              App Screenshots
            </Badge>
            <h2 className="text-4xl font-bold mb-4">See It In Action</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Take a look at our beautiful and intuitive interface designed for modern students
            </p>
          </div>

          {/* Screenshot Categories */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {["All", "Dashboard", "Attendance", "Journal", "Profile", "Information", "Mobile"].map(
              (category, index) => (
                <Button
                  key={category}
                  variant={activeScreenshot === index ? "default" : "outline"}
                  onClick={() => setActiveScreenshot(index)}
                  className="rounded-full"
                >
                  {category}
                </Button>
              ),
            )}
          </div>

          {/* Screenshots Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {screenshots.map((screenshot, index) => (
              <Card
                key={index}
                className="group border-0 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 bg-white overflow-hidden"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={screenshot.image || "/placeholder.svg"}
                    alt={screenshot.title}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                  <div className="absolute top-4 right-4">
                    <Badge className="bg-white/90 text-gray-800">{screenshot.category}</Badge>
                  </div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-2 group-hover:text-blue-600 transition-colors">
                    {screenshot.title}
                  </h3>
                  <p className="text-gray-600">{screenshot.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Device Mockups */}
          <div className="mt-20">
            <div className="text-center mb-12">
              <h3 className="text-3xl font-bold mb-4">Works on All Devices</h3>
              <p className="text-lg text-gray-600">
                Responsive design that adapts perfectly to desktop, tablet, and mobile
              </p>
            </div>

            <div className="flex justify-center items-end gap-8">
              {/* Desktop */}
              <div className="text-center">
                <div className="bg-gray-800 rounded-t-2xl p-4 mb-4">
                  <div className="bg-white rounded-lg p-4 h-48 w-64">
                    <img
                      src="/placeholder.svg?height=200&width=250"
                      alt="Desktop View"
                      className="w-full h-full object-cover rounded"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2 text-gray-600">
                  <Monitor className="h-5 w-5" />
                  <span>Desktop</span>
                </div>
              </div>

              {/* Tablet */}
              <div className="text-center">
                <div className="bg-gray-800 rounded-2xl p-3 mb-4">
                  <div className="bg-white rounded-lg p-3 h-40 w-32">
                    <img
                      src="/placeholder.svg?height=160&width=120"
                      alt="Tablet View"
                      className="w-full h-full object-cover rounded"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2 text-gray-600">
                  <Tablet className="h-5 w-5" />
                  <span>Tablet</span>
                </div>
              </div>

              {/* Mobile */}
              <div className="text-center">
                <div className="bg-gray-800 rounded-3xl p-2 mb-4">
                  <div className="bg-white rounded-2xl p-2 h-36 w-20">
                    <img
                      src="/placeholder.svg?height=140&width=75"
                      alt="Mobile View"
                      className="w-full h-full object-cover rounded-xl"
                    />
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2 text-gray-600">
                  <Smartphone className="h-5 w-5" />
                  <span>Mobile</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <Badge className="bg-purple-100 text-purple-800 border-purple-200 mb-4">
              <Zap className="h-3 w-3 mr-1" />
              Powerful Features
            </Badge>
            <h2 className="text-4xl font-bold mb-4">Everything You Need to Succeed</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Our comprehensive platform provides all the tools you need for effective educational management and
              internship tracking.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              {features.map((feature, index) => (
                <Card
                  key={index}
                  className={`cursor-pointer transition-all duration-300 ${
                    activeFeature === index
                      ? "border-blue-500 shadow-lg scale-105"
                      : "border-gray-200 hover:border-gray-300"
                  }`}
                  onClick={() => setActiveFeature(index)}
                >
                  <CardHeader>
                    <div className="flex items-center gap-4">
                      <div className={`bg-gradient-to-r ${feature.color} p-3 rounded-xl text-white`}>
                        {feature.icon}
                      </div>
                      <div>
                        <CardTitle className="text-xl">{feature.title}</CardTitle>
                        <CardDescription className="text-base">{feature.description}</CardDescription>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              ))}
            </div>

            <div className="relative">
              <div className="bg-white rounded-3xl shadow-2xl p-8 border">
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className={`bg-gradient-to-r ${features[activeFeature].color} p-4 rounded-2xl text-white`}>
                      {features[activeFeature].icon}
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold">{features[activeFeature].title}</h3>
                      <p className="text-gray-600">Advanced functionality</p>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">Performance</span>
                        <span className="text-green-600 font-bold">98%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full w-[98%]"></div>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">User Satisfaction</span>
                        <span className="text-blue-600 font-bold">95%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full w-[95%]"></div>
                      </div>
                    </div>

                    <div className="bg-gray-50 p-4 rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">Reliability</span>
                        <span className="text-purple-600 font-bold">99.9%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className="bg-purple-500 h-2 rounded-full w-[99.9%]"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-4">Why Choose Our Platform?</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Built with modern technology and designed for the future of education.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow duration-300">
                <CardContent className="p-6 text-center">
                  <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <div className="text-blue-600">{benefit.icon}</div>
                  </div>
                  <h3 className="text-xl font-bold mb-3">{benefit.title}</h3>
                  <p className="text-gray-600">{benefit.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-4xl font-bold mb-6">Ready to Transform Your Education Experience?</h2>
            <p className="text-xl mb-8 text-blue-100">
              Join thousands of students who are already using our platform to enhance their learning journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/register">
                <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 h-14 px-8 text-lg">
                  Get Started Free
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </Link>
              <Link href="/login">
                <Button
                  variant="outline"
                  size="lg"
                  className="border-white text-white hover:bg-white/10 h-14 px-8 text-lg"
                >
                  Sign In
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="bg-blue-600 p-2 rounded-lg">
                  <GraduationCap className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-xl">Student Portal</h3>
                  <p className="text-sm text-gray-400">Education Management System</p>
                </div>
              </div>
              <p className="text-gray-400 mb-4">
                Empowering students with modern tools for educational excellence and professional growth.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Features</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Attendance Tracking</li>
                <li>Digital Journal</li>
                <li>Company Integration</li>
                <li>Analytics Dashboard</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Help Center</li>
                <li>Contact Us</li>
                <li>Documentation</li>
                <li>System Status</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Student Portal. All rights reserved.</p>
            <p className="mt-2 text-sm">
              Created by <span className="text-blue-400 font-medium">v0</span> and supported by{" "}
              <span className="text-purple-400 font-medium">jns23</span>
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}
