"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { apiService } from "@/lib/api"
import { useAuth } from "@/contexts/auth-context"
import type { StudentEvent } from "@/types/api"
import { Calendar, Bell, Sparkles, BarChart3 } from "lucide-react"

export function EventsCard() {
  const { user } = useAuth()
  const [events, setEvents] = useState<StudentEvent[]>([])
  const [isLoading, setIsLoading] = useState(false)

  useEffect(() => {
    if (user) {
      fetchEvents()
    }
  }, [user])

  const fetchEvents = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const response = await apiService.getStudentEvents(user.nisn)
      if (response.success) {
        // Filter out birthday events since they're shown in popup
        // const nonBirthdayEvents = response.data.filter((event) => event.code !== "BIRTHDAY")
        // setEvents(nonBirthdayEvents)
        setEvents(response.data)
      }
    } catch (error) {
      console.error("Error fetching events:", error)
    }
    setIsLoading(false)
  }

  const getEventIcon = (code: string) => {
    switch (code) {
      case "SURVEY":
        return <BarChart3 className="h-5 w-5" />
      default:
        return <Bell className="h-5 w-5" />
    }
  }

  const getEventColor = (code: string) => {
    switch (code) {
      case "SURVEY":
        return "from-blue-500 to-indigo-500"
      default:
        return "from-purple-500 to-violet-500"
    }
  }

  const getEventBadgeColor = (code: string) => {
    switch (code) {
      case "SURVEY":
        return "bg-blue-100 text-blue-800 border-blue-200"
      default:
        return "bg-purple-100 text-purple-800 border-purple-200"
    }
  }

  const getEventTitle = (code: string) => {
    switch (code) {
      case "SURVEY":
        return "📊 Survey"
      default:
        return "📢 Event"
    }
  }

  if (!user) return null

  return (
    <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-orange-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <div className="bg-gradient-to-r from-orange-500 to-pink-500 p-2 rounded-lg">
            <Sparkles className="h-5 w-5 text-white" />
          </div>
          Events & Announcements
        </CardTitle>
        <CardDescription>Important events and announcements for you</CardDescription>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-orange-600"></div>
            <span className="ml-3 text-gray-600">Loading events...</span>
          </div>
        ) : events.length === 0 ? (
          <div className="text-center py-8">
            <Calendar className="h-12 w-12 text-gray-400 mx-auto mb-3" />
            <p className="text-gray-600 font-medium">No events at the moment</p>
            <p className="text-sm text-gray-500">Check back later for updates!</p>
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((event, index) => (
              <Alert key={index} className="border-0 p-0 bg-transparent">
                <div
                  className={`bg-gradient-to-r ${getEventColor(event.code)} p-6 rounded-xl text-white relative overflow-hidden`}
                >
                  <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
                  <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>

                  <div className="relative z-10">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="bg-white/20 p-2 rounded-lg">{getEventIcon(event.code)}</div>
                        <div>
                          <h3 className="font-bold text-lg">{event.name}</h3>
                          <Badge className={`${getEventBadgeColor(event.code)} mt-1`}>
                            {getEventTitle(event.code)}
                          </Badge>
                        </div>
                      </div>
                    </div>

                    <AlertDescription className="text-white/95 text-base leading-relaxed">
                      {event.message}
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
