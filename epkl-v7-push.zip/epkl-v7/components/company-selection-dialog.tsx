"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Card, CardContent } from "@/components/ui/card"
import { apiService } from "@/lib/api"
import { useAuth } from "@/contexts/auth-context"
import type { Dudi } from "@/types/api"
import { Building2, Search, MapPin, User, Phone, CheckCircle } from "lucide-react"
import { generateDeviceId } from "@/lib/device-id"

interface CompanySelectionDialogProps {
  isOpen: boolean
  onClose: () => void
}

export function CompanySelectionDialog({ isOpen, onClose }: CompanySelectionDialogProps) {
  const { user, updateUser } = useAuth()
  const [companies, setCompanies] = useState<Dudi[]>([])
  const [filteredCompanies, setFilteredCompanies] = useState<Dudi[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [isAssociating, setIsAssociating] = useState(false)
  const [selectedCompany, setSelectedCompany] = useState<Dudi | null>(null)
  const [message, setMessage] = useState("")

  useEffect(() => {
    if (isOpen) {
      fetchCompanies()
    }
  }, [isOpen])

  useEffect(() => {
    if (searchTerm) {
      const filtered = companies.filter(
        (company) =>
          company.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
          company.address.toLowerCase().includes(searchTerm.toLowerCase()),
      )
      setFilteredCompanies(filtered)
    } else {
      setFilteredCompanies(companies)
    }
  }, [searchTerm, companies])

  const fetchCompanies = async () => {
    setIsLoading(true)
    try {
      const response = await apiService.getDudi()
      if (response.success) {
        // Filter out deleted companies
        const activeCompanies = response.data.filter((company) => !company.deleted_at)
        setCompanies(activeCompanies)
        setFilteredCompanies(activeCompanies)
      } else {
        setMessage("Error loading companies: " + (response.message || "Unknown error"))
      }
    } catch (error) {
      console.error("Error fetching companies:", error)
      setMessage("Error loading companies")
    }
    setIsLoading(false)
  }

  const handleAssociate = async () => {
    if (!selectedCompany || !user) return

    setIsAssociating(true)
    try {
      const response = await apiService.associateDudi({
        dudi_id: selectedCompany.id,
        nisn: user.nisn,
        device_id: generateDeviceId(),
        lat: 1337,
        long: 1337,
      })

      if (response.success) {
        // Update user data with the new company
        const updatedUser = { ...user, dudi: response.data.dudi }
        updateUser(updatedUser)
        setMessage("Successfully associated with company!")
        setTimeout(() => {
          onClose()
        }, 2000)
      } else {
        setMessage(response.message || "Error associating with company")
      }
    } catch (error) {
      console.error("Error associating with company:", error)
      setMessage("Error associating with company")
    }
    setIsAssociating(false)
  }

  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
      setSelectedCompany(null)
      setSearchTerm("")
      setMessage("")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="bg-blue-500 p-2 rounded-lg">
              <Building2 className="h-5 w-5 text-white" />
            </div>
            Select Your Internship Company
          </DialogTitle>
          <DialogDescription>
            Choose the company where you'll be doing your internship. This will be used for attendance tracking.
          </DialogDescription>
        </DialogHeader>

        {message && (
          <Alert className={message.includes("Success") ? "border-green-200 bg-green-50" : ""}>
            <AlertDescription className={message.includes("Success") ? "text-green-800" : ""}>
              {message}
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-4 flex-1 overflow-hidden flex flex-col">
          {/* Search */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search companies by name or address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>

          {/* Company List */}
          <div className="flex-1 overflow-y-auto space-y-3">
            {isLoading ? (
              <div className="text-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p className="text-gray-600">Loading companies...</p>
              </div>
            ) : filteredCompanies.length === 0 ? (
              <div className="text-center py-8">
                <Building2 className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">
                  {searchTerm ? "No companies found matching your search" : "No companies available"}
                </p>
              </div>
            ) : (
              filteredCompanies.map((company) => (
                <Card
                  key={company.id}
                  className={`cursor-pointer transition-all duration-200 hover:shadow-md ${
                    selectedCompany?.id === company.id
                      ? "border-blue-500 bg-blue-50"
                      : "border-gray-200 hover:border-blue-300"
                  }`}
                  onClick={() => setSelectedCompany(company)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold text-lg">{company.name}</h3>
                          {selectedCompany?.id === company.id && <CheckCircle className="h-5 w-5 text-blue-600" />}
                        </div>

                        <div className="space-y-2 text-sm text-gray-600">
                          <div className="flex items-start gap-2">
                            <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                            <span>{company.address}</span>
                          </div>

                          {company.pic && company.pic !== "-" && (
                            <div className="flex items-center gap-2">
                              <User className="h-4 w-4" />
                              <span>PIC: {company.pic}</span>
                            </div>
                          )}

                          {company.contact && company.contact !== "0" && (
                            <div className="flex items-center gap-2">
                              <Phone className="h-4 w-4" />
                              <span>Contact: {company.contact}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      {company.logo && (
                        <img
                          src={`http://epkl.smk2-yk.sch.id${company.logo}`}
                          alt={`${company.name} logo`}
                          className="h-12 w-12 object-contain border rounded"
                        />
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 border-t">
            <Button variant="outline" onClick={() => handleOpenChange(false)} className="flex-1">
              Cancel
            </Button>
            <Button onClick={handleAssociate} disabled={!selectedCompany || isAssociating} className="flex-1">
              {isAssociating ? "Associating..." : "Select Company"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
