"use client";

import { useState, useEffect } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import {
  Sparkles,
  X,
  Zap,
  AlertTriangle,
  Bug,
  Building2,
  BookOpen,
  Gift,
  Star,
} from "lucide-react";

export function VersionUpdatePopup() {
  const [isOpen, setIsOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);

  useEffect(() => {
    // Check if user has seen this version update
    const hasSeenUpdate = localStorage.getItem("version_1.1.1_seen");
    if (!hasSeenUpdate) {
      setIsOpen(true);
      setShowConfetti(true);

      // Hide confetti after 3 seconds
      setTimeout(() => setShowConfetti(false), 3000);
    }
  }, []);

  const handleClose = () => {
    setIsOpen(false);
    setShowConfetti(false);
    // Mark this version as seen
    localStorage.setItem("version_1.1.1_seen", "true");
  };

  const features = [
    {
      icon: <Zap className="h-4 w-4 text-blue-600" />,
      title: "Auto Presence Feature",
      description:
        "Set up automatic attendance tracking in Settings menu. Configure your check-in & check-out time ranges, and the feature can be disabled anytime.",
      badge: "New",
      badgeColor: "bg-blue-100 text-blue-800 border-blue-300",
    },
  ];

  const bugFixes = [
    {
      icon: <Building2 className="h-4 w-4 text-green-600" />,
      title: "Internship Company Selection",
      description:
        "Fixed issues with company selection process for smoother user experience.",
    },
  ];

  return (
    <>
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            >
              {i % 5 === 0 ? (
                <Star className="w-3 h-3 text-yellow-400" />
              ) : i % 5 === 1 ? (
                <div className="w-2 h-2 bg-blue-400 rounded-full" />
              ) : i % 5 === 2 ? (
                <div className="w-2 h-2 bg-green-400 rounded-full" />
              ) : i % 5 === 3 ? (
                <div className="w-2 h-2 bg-purple-400 rounded-full" />
              ) : (
                <div className="w-2 h-2 bg-pink-400 rounded-full" />
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="w-[95vw] max-w-lg max-h-[90vh] overflow-y-auto border-0 p-0 bg-transparent shadow-none">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-blue-600 via-purple-600 to-indigo-700 p-4 sm:p-6 text-white">
            {/* Background decorations - smaller for mobile */}
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>

            {/* Close button - always visible and accessible */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="absolute top-2 right-2 text-white hover:bg-white/20 z-20 h-8 w-8"
            >
              <X className="h-4 w-4" />
            </Button>

            <div className="relative z-10 space-y-4">
              {/* Header - more compact */}
              <div className="text-center space-y-3">
                <div className="flex justify-center items-center gap-2 mb-3">
                  <div className="animate-pulse">
                    <Gift className="h-8 w-8 text-yellow-300" />
                  </div>
                  <div className="animate-bounce">
                    <Sparkles className="h-10 w-10 text-blue-300" />
                  </div>
                  <div
                    className="animate-pulse"
                    style={{ animationDelay: "0.5s" }}
                  >
                    <Star className="h-8 w-8 text-pink-300" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Badge className="bg-white/20 text-white border-white/30 text-sm px-3 py-1">
                    🎉 Version 1.1.1 Update
                  </Badge>
                  <h1 className="text-2xl font-bold">What's New!</h1>
                  <p className="text-blue-100 text-sm">
                    Hallo guys, ada versi baru dengan beberapa fitur kecil.
                  </p>
                </div>
              </div>

              {/* New Features - more compact */}
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="h-5 w-5 text-yellow-300" />
                  <h2 className="text-lg font-bold">✨ New Features</h2>
                </div>

                <div className="space-y-3">
                  {features.map((feature, index) => (
                    <div key={index} className="bg-white/10 rounded-lg p-3">
                      <div className="flex items-start gap-3">
                        <div className="bg-white/20 p-2 rounded-lg flex-shrink-0">
                          {feature.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2 flex-wrap">
                            <h3 className="font-semibold text-white text-sm">
                              {feature.title}
                            </h3>
                            <Badge className={`${feature.badgeColor} text-xs`}>
                              {feature.badge}
                            </Badge>
                          </div>
                          <p className="text-blue-100 text-xs leading-relaxed">
                            {feature.description}
                          </p>
                          <div className="mt-2 flex items-start gap-2 text-yellow-300">
                            <AlertTriangle className="h-3 w-3 mt-0.5 flex-shrink-0" />
                            <span className="text-xs font-medium">
                              Tapi jangan dibuat untuk nakal, ygy. Ini juga
                              masih experimental 😊
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bug Fixes - more compact */}
              <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="flex items-center gap-2 mb-3">
                  <Bug className="h-5 w-5 text-green-300" />
                  <h2 className="text-lg font-bold">🐛 Bug Fixes</h2>
                </div>

                <div className="space-y-2">
                  {bugFixes.map((fix, index) => (
                    <div key={index} className="bg-white/10 rounded-lg p-3">
                      <div className="flex items-start gap-3">
                        <div className="bg-white/20 p-2 rounded-lg flex-shrink-0">
                          {fix.icon}
                        </div>
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-white mb-1 text-sm">
                            {fix.title}
                          </h3>
                          <p className="text-green-100 text-xs leading-relaxed">
                            {fix.description}
                          </p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <Separator className="bg-white/20" />

              {/* Reminder - more compact */}
              <div className="bg-gradient-to-r from-orange-500/20 to-pink-500/20 backdrop-blur-sm rounded-xl p-4 border border-orange-300/30">
                <div className="flex items-center gap-2 mb-2">
                  <BookOpen className="h-5 w-5 text-orange-300" />
                  <h2 className="text-lg font-bold text-orange-100">
                    📝 Reminder
                  </h2>
                </div>
                <p className="text-orange-100 leading-relaxed text-sm">
                  Mungkin beberapa ada yang belum tau, di sini ada fitur{" "}
                  <strong>jurnal</strong> harian. Tapi entah pembimbing kalian
                  ngecekin jurnal kalian ga, tapi kalo mau diisi silahkan 🚀
                </p>
              </div>

              {/* Action button */}
              <div className="text-center pt-2">
                <Button
                  onClick={handleClose}
                  className="bg-white/20 text-white border-white/30 hover:bg-white/30 px-6 py-2 text-base font-semibold backdrop-blur-sm w-full sm:w-auto"
                  size="lg"
                >
                  Siap, Let's Go! 🚀
                </Button>
              </div>
            </div>

            {/* Floating emojis - smaller and fewer for mobile */}
            <div className="absolute top-6 left-4 text-lg animate-bounce">
              ⚡
            </div>
            <div
              className="absolute top-12 right-12 text-lg animate-bounce"
              style={{ animationDelay: "0.5s" }}
            >
              🎯
            </div>
            <div
              className="absolute bottom-12 left-12 text-lg animate-bounce"
              style={{ animationDelay: "1s" }}
            >
              🔧
            </div>
            <div
              className="absolute bottom-6 right-6 text-lg animate-bounce"
              style={{ animationDelay: "1.5s" }}
            >
              ✨
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
