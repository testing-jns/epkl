"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { apiService } from "@/lib/api"
import { Calendar, User, ImageIcon, AlertCircle } from "lucide-react"
import { format } from "date-fns"

interface InfoDetailDialogProps {
  infoId: number | null
  isOpen: boolean
  onClose: () => void
}

interface InfoDetail {
  id: number
  title: string
  info: string
  image: string | null
  other: string | null
  created_by: string
  created_at: string
  updated_at: string
}

export function InfoDetailDialog({ infoId, isOpen, onClose }: InfoDetailDialogProps) {
  const [infoDetail, setInfoDetail] = useState<InfoDetail | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  // Fetch data when dialog opens and infoId is available
  useEffect(() => {
    if (isOpen && infoId) {
      fetchInfoDetail(infoId)
    }
  }, [isOpen, infoId])

  // Reset state when dialog closes
  useEffect(() => {
    if (!isOpen) {
      setInfoDetail(null)
      setError(null)
      setIsLoading(false)
    }
  }, [isOpen])

  const fetchInfoDetail = async (id: number) => {
    setIsLoading(true)
    setError(null)
    try {
      console.log("Fetching info detail for ID:", id) // Debug log
      const response = await apiService.getInfoDetail(id)
      console.log("Info detail response:", response) // Debug log

      if (response.success) {
        setInfoDetail(response.data)
      } else {
        setError(response.message || "Failed to load information details")
      }
    } catch (error) {
      console.error("Error fetching info detail:", error)
      setError("Failed to load information details")
    }
    setIsLoading(false)
  }

  // Simplified handleOpenChange - only handle closing
  const handleOpenChange = (open: boolean) => {
    if (!open) {
      onClose()
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader className="space-y-4">
          <DialogTitle className="text-2xl font-bold leading-tight">
            {isLoading ? "Loading..." : error ? "Error" : infoDetail?.title || "Information Details"}
          </DialogTitle>
          <DialogDescription className="text-muted-foreground">
            {isLoading
              ? "Please wait while we load the information details..."
              : error
                ? "There was an error loading the information details."
                : "Detailed information and announcements"}
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600"></div>
            <span className="ml-3">Loading information details...</span>
          </div>
        ) : error ? (
          <div className="text-center py-12">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          </div>
        ) : infoDetail ? (
          <div className="space-y-6">
            <div className="flex items-center gap-4 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4" />
                <span>{format(new Date(infoDetail.created_at), "MMMM d, yyyy 'at' HH:mm")}</span>
              </div>
              <div className="flex items-center gap-2">
                <User className="h-4 w-4" />
                <span>By: {infoDetail.created_by}</span>
              </div>
              <Badge variant="outline">Announcement</Badge>
            </div>

            {infoDetail.image && (
              <div className="relative overflow-hidden rounded-xl">
                <img
                  src={`http://epkl.smk2-yk.sch.id${infoDetail.image}`}
                  alt={infoDetail.title}
                  className="w-full max-h-96 object-cover"
                  onError={(e) => {
                    console.error("Error loading image:", infoDetail.image)
                    e.currentTarget.style.display = "none"
                  }}
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
              </div>
            )}

            <div className="prose prose-gray max-w-none">
              <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-6 rounded-xl border-2 border-orange-200">
                <h3 className="text-lg font-semibold text-orange-900 mb-3 flex items-center gap-2">
                  <ImageIcon className="h-5 w-5" />
                  Information Details
                </h3>
                <div className="text-gray-800 leading-relaxed whitespace-pre-wrap">{infoDetail.info}</div>
              </div>
            </div>

            {infoDetail.other && (
              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border-2 border-blue-200">
                <h3 className="text-lg font-semibold text-blue-900 mb-3">Additional Information</h3>
                <div className="text-gray-800 leading-relaxed whitespace-pre-wrap">{infoDetail.other}</div>
              </div>
            )}

            <div className="flex items-center justify-between pt-4 border-t border-gray-200 text-sm text-muted-foreground">
              <span>Created: {format(new Date(infoDetail.created_at), "PPP")}</span>
              <span>Updated: {format(new Date(infoDetail.updated_at), "PPP")}</span>
            </div>
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No information details available.</p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
