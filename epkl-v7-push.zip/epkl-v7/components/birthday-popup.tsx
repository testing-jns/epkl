"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { apiService } from "@/lib/api"
import { useAuth } from "@/contexts/auth-context"
import type { StudentEvent } from "@/types/api"
import { Gift, PartyPopper, Cake, Heart, Sparkles, X } from "lucide-react"

export function BirthdayPopup() {
  const { user } = useAuth()
  const [birthdayEvent, setBirthdayEvent] = useState<StudentEvent | null>(null)
  const [isOpen, setIsOpen] = useState(false)
  const [showConfetti, setShowConfetti] = useState(false)

  useEffect(() => {
    if (user) {
      checkForBirthday()
    }
  }, [user])

  const checkForBirthday = async () => {
    if (!user) return

    try {
      const response = await apiService.getStudentEvents(user.nisn)
      if (response.success) {
        const birthday = response.data.find((event) => event.code === "BIRTHDAY")
        if (birthday) {
          setBirthdayEvent(birthday)
          setIsOpen(true)
          setShowConfetti(true)

          // Hide confetti after 3 seconds
          setTimeout(() => setShowConfetti(false), 3000)
        }
      }
    } catch (error) {
      console.error("Error checking for birthday:", error)
    }
  }

  const handleClose = () => {
    setIsOpen(false)
    setShowConfetti(false)
  }

  if (!birthdayEvent) return null

  return (
    <>
      {/* Confetti Effect */}
      {showConfetti && (
        <div className="fixed inset-0 pointer-events-none z-[100] overflow-hidden">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            >
              {i % 4 === 0 ? (
                <div className="w-3 h-3 bg-pink-400 rounded-full" />
              ) : i % 4 === 1 ? (
                <div className="w-3 h-3 bg-yellow-400 rounded-full" />
              ) : i % 4 === 2 ? (
                <div className="w-3 h-3 bg-blue-400 rounded-full" />
              ) : (
                <div className="w-3 h-3 bg-green-400 rounded-full" />
              )}
            </div>
          ))}
        </div>
      )}

      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogContent className="w-[95vw] max-w-md max-h-[90vh] overflow-y-auto border-0 p-0 bg-transparent shadow-none">
          <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-600 p-4 sm:p-6 text-white">
            {/* Background decorations - smaller for mobile */}
            <div className="absolute inset-0 bg-black/10"></div>
            <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-16 translate-x-16"></div>
            <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-12 -translate-x-12"></div>
            <div className="absolute top-1/2 left-1/2 w-16 h-16 bg-white/5 rounded-full -translate-x-8 -translate-y-8"></div>

            {/* Close button - always visible and accessible */}
            <Button
              variant="ghost"
              size="icon"
              onClick={handleClose}
              className="absolute top-2 right-2 text-white hover:bg-white/20 z-20 h-10 w-10 bg-black/20 backdrop-blur-sm border border-white/30"
            >
              <X className="h-5 w-5" />
            </Button>

            <div className="relative z-10 text-center space-y-6">
              {/* Header with icons - more compact for mobile */}
              <div className="flex justify-center items-center gap-2 sm:gap-4 mb-4 sm:mb-6">
                <div className="animate-bounce">
                  <Gift className="h-8 w-8 sm:h-12 sm:w-12 text-yellow-300" />
                </div>
                <div className="animate-pulse">
                  <Cake className="h-10 w-10 sm:h-16 sm:w-16 text-pink-300" />
                </div>
                <div className="animate-bounce" style={{ animationDelay: "0.5s" }}>
                  <PartyPopper className="h-8 w-8 sm:h-12 sm:w-12 text-blue-300" />
                </div>
              </div>

              {/* Birthday message - more compact for mobile */}
              <div className="space-y-3 sm:space-y-4">
                <div className="flex items-center justify-center gap-2">
                  <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-300 animate-pulse" />
                  <h1 className="text-2xl sm:text-4xl font-bold">Happy Birthday!</h1>
                  <Sparkles className="h-5 w-5 sm:h-6 sm:w-6 text-yellow-300 animate-pulse" />
                </div>

                <h2 className="text-lg sm:text-2xl font-semibold text-pink-100">{birthdayEvent.name} 🎂</h2>

                <div className="bg-white/20 backdrop-blur-sm rounded-xl sm:rounded-2xl p-4 sm:p-6 mx-2 sm:mx-4">
                  <p className="text-sm sm:text-lg leading-relaxed text-white/95">{birthdayEvent.message}</p>
                </div>
              </div>

              {/* Decorative elements - smaller for mobile */}
              <div className="flex justify-center items-center gap-4 sm:gap-8 mt-4 sm:mt-8">
                <div className="animate-pulse">
                  <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-red-300" />
                </div>
                <div className="text-4xl sm:text-6xl animate-bounce">🎉</div>
                <div className="animate-pulse" style={{ animationDelay: "1s" }}>
                  <Heart className="h-6 w-6 sm:h-8 sm:w-8 text-red-300" />
                </div>
              </div>

              {/* Action button - full width on mobile */}
              <div className="pt-4 sm:pt-6">
                <Button
                  onClick={handleClose}
                  className="bg-white/20 text-white border-white/30 hover:bg-white/30 px-6 sm:px-8 py-2 sm:py-3 text-base sm:text-lg font-semibold backdrop-blur-sm w-full sm:w-auto"
                  size="lg"
                >
                  Thank You! 🥳
                </Button>
              </div>
            </div>

            {/* Floating emojis - smaller and fewer for mobile */}
            <div className="absolute top-4 sm:top-8 left-4 sm:left-8 text-lg sm:text-2xl animate-bounce">🎈</div>
            <div
              className="absolute top-8 sm:top-16 right-8 sm:right-16 text-lg sm:text-2xl animate-bounce"
              style={{ animationDelay: "0.5s" }}
            >
              🎊
            </div>
            <div
              className="absolute bottom-8 sm:bottom-16 left-8 sm:left-16 text-lg sm:text-2xl animate-bounce"
              style={{ animationDelay: "1s" }}
            >
              🎁
            </div>
            <div
              className="absolute bottom-4 sm:bottom-8 right-4 sm:right-8 text-lg sm:text-2xl animate-bounce"
              style={{ animationDelay: "1.5s" }}
            >
              🍰
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
