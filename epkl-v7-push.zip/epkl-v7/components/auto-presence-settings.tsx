"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { apiService } from "@/lib/api"
import { useAuth } from "@/contexts/auth-context"
import {
  Clock,
  Settings,
  Save,
  Trash2,
  CheckCircle,
  AlertCircle,
  Zap,
  Timer,
  Calendar,
  RefreshCw,
  Info,
  CalendarX,
} from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"

const DAYS_OF_WEEK = [
  { value: "Sunday", label: "Sunday", emoji: "🌅" },
  { value: "Monday", label: "Monday", emoji: "💼" },
  { value: "Tuesday", label: "Tuesday", emoji: "📚" },
  { value: "Wednesday", label: "Wednesday", emoji: "⚡" },
  { value: "Thursday", label: "Thursday", emoji: "🎯" },
  { value: "Friday", label: "Friday", emoji: "🎉" },
  { value: "Saturday", label: "Saturday", emoji: "🏖️" },
]

export function AutoPresenceSettingsComponent() {
  const { user } = useAuth()
  const [settings, setSettings] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [isDeleting, setIsDeleting] = useState(false)
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [message, setMessage] = useState("")
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [formData, setFormData] = useState({
    check_in_start: "07:30",
    check_in_end: "08:00",
    check_out_start: "17:00",
    check_out_end: "17:30",
    except_days: [] as string[],
  })

  useEffect(() => {
    if (user) {
      fetchSettings()
    }
  }, [user])

  const fetchSettings = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const response = await apiService.getAutoPresenceStatus(user.nisn)
      if (response.success && response.data.length > 0) {
        const autoPresenceSettings = response.data.find((s) => s.code === "AUTOPRESENSI")
        if (autoPresenceSettings) {
          setSettings(autoPresenceSettings)
          setFormData({
            check_in_start: autoPresenceSettings.check_in_start,
            check_in_end: autoPresenceSettings.check_in_end,
            check_out_start: autoPresenceSettings.check_out_start,
            check_out_end: autoPresenceSettings.check_out_end,
            except_days: autoPresenceSettings.except_days || [],
          })
        }
      }
    } catch (error) {
      console.error("Error fetching auto presence settings:", error)
    }
    setIsLoading(false)
  }

  const handleRefresh = async () => {
    if (!user) return

    setIsRefreshing(true)
    try {
      await fetchSettings()
      setMessage("Settings refreshed successfully!")
      setTimeout(() => setMessage(""), 3000)
    } catch (error) {
      console.error("Error refreshing settings:", error)
      setMessage("Error refreshing settings")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsRefreshing(false)
  }

  const handleSave = async () => {
    if (!user) return

    setIsSaving(true)
    try {
      const requestData = {
        CODE: "AUTOPRESENSI",
        ...formData,
      }

      const response = settings
        ? await apiService.updateAutoPresenceSettings(user.nisn, requestData)
        : await apiService.createAutoPresenceSettings(user.nisn, requestData)

      if (response.success) {
        setSettings(response.data)
        setMessage(settings ? "Auto presence settings updated successfully!" : "Auto presence enabled successfully!")
        setTimeout(() => setMessage(""), 3000)
      } else {
        setMessage(response.message || "Error saving settings")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error saving auto presence settings:", error)
      setMessage("Error saving settings")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsSaving(false)
  }

  const handleDelete = async () => {
    if (!user) return

    setIsDeleting(true)
    try {
      const response = await apiService.deleteAutoPresenceSettings(user.nisn)
      if (response.success) {
        setSettings(null)
        setFormData({
          check_in_start: "07:30",
          check_in_end: "08:00",
          check_out_start: "17:00",
          check_out_end: "17:30",
          except_days: [],
        })
        setMessage("Auto presence disabled successfully!")
        setTimeout(() => setMessage(""), 3000)
      } else {
        setMessage(response.message || "Error disabling auto presence")
        setTimeout(() => setMessage(""), 3000)
      }
    } catch (error) {
      console.error("Error deleting auto presence settings:", error)
      setMessage("Error disabling auto presence")
      setTimeout(() => setMessage(""), 3000)
    }
    setIsDeleting(false)
    setShowDeleteDialog(false)
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleExceptDayToggle = (day: string, checked: boolean) => {
    setFormData((prev) => ({
      ...prev,
      except_days: checked ? [...prev.except_days, day] : prev.except_days.filter((d) => d !== day),
    }))
  }

  if (!user) return null

  const isEnabled = !!settings
  const workingDays = DAYS_OF_WEEK.filter((day) => !formData.except_days.includes(day.value))
  const exceptDays = DAYS_OF_WEEK.filter((day) => formData.except_days.includes(day.value))

  return (
    <Card className="border-0 shadow-xl bg-gradient-to-br from-white to-blue-50">
      <CardHeader>
        <CardTitle className="flex items-center gap-3">
          <div className="bg-gradient-to-r from-blue-500 to-indigo-500 p-2 rounded-lg">
            <Zap className="h-5 w-5 text-white" />
          </div>
          Auto Presence Settings
        </CardTitle>
        <CardDescription>
          Configure automatic attendance tracking with customizable time windows and exception days
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {message && (
          <Alert className={message.includes("success") ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"}>
            {message.includes("success") ? (
              <CheckCircle className="h-4 w-4 text-green-600" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-600" />
            )}
            <AlertDescription className={message.includes("success") ? "text-green-800" : "text-red-800"}>
              {message}
            </AlertDescription>
          </Alert>
        )}

        {/* Status Section */}
        <div className="bg-white p-6 rounded-xl border-2 border-blue-100">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className={`p-2 rounded-lg ${isEnabled ? "bg-green-100" : "bg-gray-100"}`}>
                <Timer className={`h-5 w-5 ${isEnabled ? "text-green-600" : "text-gray-600"}`} />
              </div>
              <div>
                <h3 className="font-semibold text-lg">Auto Presence Status</h3>
                <p className="text-sm text-gray-600">
                  {isEnabled ? "Automatic attendance is active" : "Automatic attendance is disabled"}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge variant={isEnabled ? "default" : "secondary"} className="text-sm px-3 py-1">
                {isEnabled ? "🟢 Enabled" : "🔴 Disabled"}
              </Badge>
              {isEnabled && (
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleRefresh}
                  disabled={isRefreshing}
                  className="h-8 bg-transparent"
                >
                  <RefreshCw className={`h-4 w-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
                  {isRefreshing ? "Refreshing..." : "Refresh"}
                </Button>
              )}
            </div>
          </div>

          {isEnabled && settings && (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
                <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-4 w-4 text-green-600" />
                    <span className="font-medium text-green-900">Next Check-in</span>
                  </div>
                  <p className="text-2xl font-bold text-green-800">{settings.fix_check_in}</p>
                  <p className="text-sm text-green-600">
                    Window: {settings.check_in_start} - {settings.check_in_end}
                  </p>
                </div>

                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <div className="flex items-center gap-2 mb-2">
                    <Clock className="h-4 w-4 text-blue-600" />
                    <span className="font-medium text-blue-900">Next Check-out</span>
                  </div>
                  <p className="text-2xl font-bold text-blue-800">{settings.fix_check_out}</p>
                  <p className="text-sm text-blue-600">
                    Window: {settings.check_out_start} - {settings.check_out_end}
                  </p>
                </div>
              </div>

              {/* Working Days Display */}
              {(workingDays.length > 0 || exceptDays.length > 0) && (
                <div className="mt-4 space-y-3">
                  {workingDays.length > 0 && (
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <div className="flex items-center gap-2 mb-2">
                        <Calendar className="h-4 w-4 text-green-600" />
                        <span className="font-medium text-green-900">Working Days</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {workingDays.map((day) => (
                          <Badge
                            key={day.value}
                            variant="outline"
                            className="border-green-300 text-green-700 bg-green-100"
                          >
                            {day.emoji} {day.label}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  {exceptDays.length > 0 && (
                    <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                      <div className="flex items-center gap-2 mb-2">
                        <CalendarX className="h-4 w-4 text-red-600" />
                        <span className="font-medium text-red-900">Exception Days (No Auto Presence)</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {exceptDays.map((day) => (
                          <Badge key={day.value} variant="outline" className="border-red-300 text-red-700 bg-red-100">
                            {day.emoji} {day.label}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Important Note */}
              <Alert className="mt-4 border-amber-200 bg-amber-50">
                <Info className="h-4 w-4 text-amber-600" />
                <AlertDescription className="text-amber-800">
                  <strong>Important:</strong> After the check-out time ({settings.fix_check_out}), the system will
                  automatically generate new check-in and check-out times for the next day based on your configured time
                  windows. Use the refresh button above to see the updated schedule.
                </AlertDescription>
              </Alert>
            </>
          )}
        </div>

        {/* Configuration Section */}
        <div className="bg-white p-6 rounded-xl border-2 border-blue-100">
          <div className="flex items-center gap-3 mb-6">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Settings className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg">Time Configuration</h3>
              <p className="text-sm text-gray-600">Set your preferred check-in and check-out time windows</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Check-in Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="h-4 w-4 text-green-600" />
                <h4 className="font-medium text-green-900">Check-in Window</h4>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="check_in_start" className="text-sm font-medium">
                    Start Time
                  </Label>
                  <Input
                    id="check_in_start"
                    type="time"
                    value={formData.check_in_start}
                    onChange={(e) => handleInputChange("check_in_start", e.target.value)}
                    className="mt-1 border-2 border-green-200 focus:border-green-400"
                  />
                </div>

                <div>
                  <Label htmlFor="check_in_end" className="text-sm font-medium">
                    End Time
                  </Label>
                  <Input
                    id="check_in_end"
                    type="time"
                    value={formData.check_in_end}
                    onChange={(e) => handleInputChange("check_in_end", e.target.value)}
                    className="mt-1 border-2 border-green-200 focus:border-green-400"
                  />
                </div>
              </div>
            </div>

            {/* Check-out Settings */}
            <div className="space-y-4">
              <div className="flex items-center gap-2 mb-3">
                <Calendar className="h-4 w-4 text-blue-600" />
                <h4 className="font-medium text-blue-900">Check-out Window</h4>
              </div>

              <div className="space-y-3">
                <div>
                  <Label htmlFor="check_out_start" className="text-sm font-medium">
                    Start Time
                  </Label>
                  <Input
                    id="check_out_start"
                    type="time"
                    value={formData.check_out_start}
                    onChange={(e) => handleInputChange("check_out_start", e.target.value)}
                    className="mt-1 border-2 border-blue-200 focus:border-blue-400"
                  />
                </div>

                <div>
                  <Label htmlFor="check_out_end" className="text-sm font-medium">
                    End Time
                  </Label>
                  <Input
                    id="check_out_end"
                    type="time"
                    value={formData.check_out_end}
                    onChange={(e) => handleInputChange("check_out_end", e.target.value)}
                    className="mt-1 border-2 border-blue-200 focus:border-blue-400"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Exception Days Section */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-red-100 p-2 rounded-lg">
                <CalendarX className="h-5 w-5 text-red-600" />
              </div>
              <div>
                <h4 className="font-medium text-red-900">Exception Days</h4>
                <p className="text-sm text-gray-600">Select days when auto presence should NOT work</p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {DAYS_OF_WEEK.map((day) => (
                <div key={day.value} className="flex items-center space-x-3">
                  <Checkbox
                    id={`except-${day.value}`}
                    checked={formData.except_days.includes(day.value)}
                    onCheckedChange={(checked) => handleExceptDayToggle(day.value, checked as boolean)}
                    className="border-2"
                  />
                  <Label
                    htmlFor={`except-${day.value}`}
                    className={`text-sm font-medium cursor-pointer flex items-center gap-2 ${
                      formData.except_days.includes(day.value) ? "text-red-700" : "text-gray-700"
                    }`}
                  >
                    <span>{day.emoji}</span>
                    <span>{day.label}</span>
                  </Label>
                </div>
              ))}
            </div>

            {formData.except_days.length > 0 && (
              <Alert className="mt-4 border-red-200 bg-red-50">
                <CalendarX className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  <strong>Note:</strong> Auto presence will be disabled on{" "}
                  <strong>{formData.except_days.join(", ")}</strong>. You'll need to manually check-in and check-out on
                  these days.
                </AlertDescription>
              </Alert>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 mt-6 pt-6 border-t border-gray-200">
            <Button
              onClick={handleSave}
              disabled={isSaving || isLoading}
              className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 h-12"
            >
              <Save className="h-4 w-4 mr-2" />
              {isSaving ? "Saving..." : isEnabled ? "Update Settings" : "Enable Auto Presence"}
            </Button>

            {isEnabled && (
              <Button
                variant="destructive"
                onClick={() => setShowDeleteDialog(true)}
                disabled={isDeleting || isLoading}
                className="h-12 px-6"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Disable
              </Button>
            )}
          </div>
        </div>

        {/* Delete Confirmation Dialog */}
        <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
          <AlertDialogContent>
            <AlertDialogHeader>
              <AlertDialogTitle>Disable Auto Presence?</AlertDialogTitle>
              <AlertDialogDescription>
                This will disable automatic attendance tracking. You'll need to manually check-in and check-out. This
                action cannot be undone, but you can re-enable it anytime.
              </AlertDialogDescription>
            </AlertDialogHeader>
            <AlertDialogFooter>
              <AlertDialogCancel>Cancel</AlertDialogCancel>
              <AlertDialogAction onClick={handleDelete} disabled={isDeleting} className="bg-red-600 hover:bg-red-700">
                {isDeleting ? "Disabling..." : "Yes, Disable"}
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      </CardContent>
    </Card>
  )
}
