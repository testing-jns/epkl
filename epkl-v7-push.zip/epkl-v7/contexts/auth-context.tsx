"use client"

import { createContext, useContext, useEffect, useState, type ReactNode } from "react"
import type { Student } from "@/types/api"
import { apiService } from "@/lib/api"

interface AuthContextType {
  user: Student | null
  token: string | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  updateUser: (user: Student) => void
  isLoading: boolean
  refreshUserProfile: () => Promise<void>
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<Student | null>(null)
  const [token, setToken] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    const storedToken = localStorage.getItem("token")
    const storedUser = localStorage.getItem("user")

    if (storedToken && storedUser) {
      setToken(storedToken)
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const response = await apiService.login(email, password)
      if (response.success) {
        setToken(response.data.token)
        setUser(response.data.user)
        localStorage.setItem("token", response.data.token)
        localStorage.setItem("user", JSON.stringify(response.data.user))

        // Fetch complete profile after login to get updated dudi information
        try {
          const profileResponse = await apiService.getProfile(response.data.user.nisn)
          if (profileResponse.success) {
            setUser(profileResponse.data)
            localStorage.setItem("user", JSON.stringify(profileResponse.data))
          }
        } catch (profileError) {
          console.error("Error fetching complete profile after login:", profileError)
          // Don't fail the login if profile fetch fails, just log the error
        }

        return true
      }
      return false
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    setToken(null)
    localStorage.removeItem("token")
    localStorage.removeItem("user")
  }

  const updateUser = (updatedUser: Student) => {
    setUser(updatedUser)
    localStorage.setItem("user", JSON.stringify(updatedUser))
  }

  // Add a function to refresh the user profile
  const refreshUserProfile = async () => {
    if (!user || !token) return

    try {
      const response = await apiService.getProfile(user.nisn)
      if (response.success) {
        setUser(response.data)
        localStorage.setItem("user", JSON.stringify(response.data))
      }
    } catch (error) {
      console.error("Error refreshing user profile:", error)
    }
  }

  // Add refreshUserProfile to the context value
  return (
    <AuthContext.Provider value={{ user, token, login, logout, updateUser, isLoading, refreshUserProfile }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
