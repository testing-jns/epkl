import type {
  ApiResponse,
  Jurusan,
  Kelas,
  Student,
  LoginResponse,
  Dudi,
  Attendance,
  Journal,
  Info,
  StudentEvent,
  AutoPresenceSettings,
  AutoPresenceRequest,
} from "@/types/api"

const BASE_URL = "http://epkl.smk2-yk.sch.id"
const NEW_BASE_URL = "http://localhost:5000"

class ApiService {
  private getAuthHeaders() {
    const token = localStorage.getItem("token")
    return {
      "Content-Type": "application/json",
      ...(token && { Authorization: `Bearer ${token}` }),
    }
  }

  private getNewAuthHeaders() {
    const token = localStorage.getItem("token")
    return {
      "Content-Type": "application/json",
      ...(token && { Authorization: token }), // No Bearer prefix for new endpoints
    }
  }

  async get<T>(endpoint: string): Promise<ApiResponse<T>> {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      headers: this.getAuthHeaders(),
    })
    return response.json()
  }

  async post<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      headers: this.getAuthHeaders(),
      body: JSON.stringify(data),
    })
    return response.json()
  }

  async postFormData<T>(endpoint: string, formData: FormData): Promise<ApiResponse<T>> {
    const token = localStorage.getItem("token")
    const response = await fetch(`${BASE_URL}${endpoint}`, {
      method: "POST",
      headers: {
        ...(token && { Authorization: `Bearer ${token}` }),
      },
      body: formData,
    })
    return response.json()
  }

  // New API methods for the new endpoints
  async getNew<T>(endpoint: string): Promise<ApiResponse<T>> {
    const response = await fetch(`${NEW_BASE_URL}${endpoint}`, {
      headers: this.getNewAuthHeaders(),
    })
    return response.json()
  }

  async postNew<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${NEW_BASE_URL}${endpoint}`, {
      method: "POST",
      headers: this.getNewAuthHeaders(),
      body: JSON.stringify(data),
    })
    return response.json()
  }

  async putNew<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${NEW_BASE_URL}${endpoint}`, {
      method: "PUT",
      headers: this.getNewAuthHeaders(),
      body: JSON.stringify(data),
    })
    return response.json()
  }

  async deleteNew<T>(endpoint: string, data?: any): Promise<ApiResponse<T>> {
    const response = await fetch(`${NEW_BASE_URL}${endpoint}`, {
      method: "DELETE",
      headers: this.getNewAuthHeaders(),
      ...(data && { body: JSON.stringify(data) }),
    })
    return response.json()
  }

  // Auth endpoints
  async login(email: string, password: string) {
    return this.post<LoginResponse>("/api/login/siswa", { email, password })
  }

  async register(data: {
    nisn: string
    name: string
    email: string
    m_jurusan_id: number
    m_kelas_id: number
    phone: string
    password: string
    password_confirmation: string
    semester: string
    year: string
    device_id: string
  }) {
    return this.post<Student>("/api/siswa/register", data)
  }

  // Master data
  async getJurusan() {
    return this.get<Jurusan[]>("/api/jurusan")
  }

  async getKelas() {
    return this.get<Kelas[]>("/api/kelas")
  }

  async getDudi() {
    return this.get<Dudi[]>("/api/dudi")
  }

  // Student profile
  async getProfile(nisn: string) {
    return this.get<Student>(`/api/siswa/profile?nisn=${nisn}`)
  }

  async updateAvatar(nisn: string, avatar: File) {
    const formData = new FormData()
    formData.append("nisn", nisn)
    formData.append("avatar", avatar)
    return this.postFormData<Student>("/api/siswa/profile/avatar", formData)
  }

  // Attendance
  async checkIn(nisn: string, date: string) {
    return this.post<Attendance>(`/api/attendance/check-in?nisn=${nisn}&date=${date}`)
  }

  async checkOut(nisn: string, date: string) {
    return this.post<Attendance>(`/api/attendance/check-out?nisn=${nisn}&date=${date}`)
  }

  async getAttendanceList(nisn: string, dateStart: string, dateEnd: string) {
    return this.get<Attendance[]>(`/api/attendance/list?nisn=${nisn}&date_start=${dateStart}&date_end=${dateEnd}`)
  }

  // Journal
  async createJournal(nisn: string, data: { tanggal: string; kegiatan: string; target: string }) {
    return this.post<Journal>(`/api/journal?nisn=${nisn}`, data)
  }

  async getJournals(nisn: string) {
    return this.get<Journal[]>(`/api/journal?nisn=${nisn}`)
  }

  // Info
  async getInfo() {
    return this.get<{ meta: any; info: Info[] }>("/api/info")
  }

  // Info detail - explicitly ensure authorization header is included
  async getInfoDetail(id: number) {
    const token = localStorage.getItem("token")
    const response = await fetch(`${BASE_URL}/api/info?id=${id}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        ...(token && { Authorization: `Bearer ${token}` }),
      },
    })
    return response.json() as Promise<
      ApiResponse<{
        id: number
        title: string
        info: string
        image: string | null
        other: string | null
        created_by: string
        created_at: string
        updated_at: string
      }>
    >
  }

  // DUDI Association
  async associateDudi(data: {
    dudi_id: number
    nisn: string
    device_id: string
    lat: number
    long: number
  }) {
    return this.post<{ nisn: string; name: string; dudi: Dudi }>("/api/dudi/associate", data)
  }

  // Profile update (using POST method)
  async updateProfile(
    nisn: string,
    data: {
      name: string
      phone: string
    },
  ) {
    return this.post<Student>("/api/siswa/profile", { nisn, ...data })
  }

  // New API endpoints for Events and Auto Presence

  // Get student events (birthdays, surveys, etc.)
  async getStudentEvents(nisn: string) {
    return this.getNew<StudentEvent[]>(`/api/v1/students/${nisn}/events`)
  }

  // Get auto presence settings
  async getAutoPresenceStatus(nisn: string) {
    return this.getNew<AutoPresenceSettings[]>(`/api/v1/students/${nisn}/settings`)
  }

  // Create auto presence settings
  async createAutoPresenceSettings(nisn: string, data: AutoPresenceRequest) {
    return this.postNew<AutoPresenceSettings>(`/api/v1/students/${nisn}/settings`, data)
  }

  // Update auto presence settings
  async updateAutoPresenceSettings(nisn: string, data: AutoPresenceRequest) {
    return this.putNew<AutoPresenceSettings>(`/api/v1/students/${nisn}/settings`, data)
  }

  // Delete auto presence settings - now includes CODE field
  async deleteAutoPresenceSettings(nisn: string) {
    return this.deleteNew<any>(`/api/v1/students/${nisn}/settings`, {
      CODE: "AUTOPRESENSI",
    })
  }
}

export const apiService = new ApiService()
